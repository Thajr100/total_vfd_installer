# -*- coding: utf-8 -*-

from odoo import api, fields, models

from odoo.addons.total_vfd.services.license_constants import (
    GRANT_STATE_ACTIVATED,
    GRANT_STATE_REVOKED,
    GRANT_STATE_UNUSED,
)


class TotalVfdLicenseGrant(models.Model):
    """Legacy audit records only — keys are not issued inside Odoo."""

    _name = 'total.vfd.license.grant'
    _description = 'Total VFD Module License Grant (legacy)'
    _order = 'create_date desc'

    name = fields.Char(string='Reference', required=True, readonly=True, copy=False)
    license_word = fields.Char(string='License Word', required=True, readonly=True, index=True)
    license_key_hash = fields.Char(string='License Key Hash', required=True, readonly=True)
    verification_token = fields.Char(string='Verification Token', readonly=True)
    state = fields.Selection(
        selection=[
            (GRANT_STATE_UNUSED, 'Unused'),
            (GRANT_STATE_ACTIVATED, 'Activated'),
            (GRANT_STATE_REVOKED, 'Revoked'),
        ],
        string='State',
        default=GRANT_STATE_UNUSED,
        required=True,
        readonly=True,
        index=True,
    )
    license_id = fields.Many2one(
        'total.vfd.license',
        string='Activated License',
        readonly=True,
        ondelete='set null',
    )
    notes = fields.Text(string='Notes')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('name'):
                vals['name'] = self.env['ir.sequence'].next_by_code('total.vfd.license.grant') or '/'
        return super().create(vals_list)

    def action_revoke(self):
        for record in self.filtered(lambda g: g.state == GRANT_STATE_UNUSED):
            record.sudo().write({'state': GRANT_STATE_REVOKED})
