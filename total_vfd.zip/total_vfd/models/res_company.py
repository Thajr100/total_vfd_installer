# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.tools import sql


class ResCompany(models.Model):
    _inherit = 'res.company'

    def _auto_init(self):
        """Create columns when code is deployed without running -u total_vfd."""
        res = super()._auto_init()
        if not sql.column_exists(self._cr, self._table, 'totalvfd_convert_foreign_currency'):
            sql.create_column(
                self._cr,
                self._table,
                'totalvfd_convert_foreign_currency',
                'boolean',
            )
            self._cr.execute(
                """
                UPDATE res_company
                SET totalvfd_convert_foreign_currency = TRUE
                WHERE totalvfd_convert_foreign_currency IS NULL
                """
            )
        return res

    @api.model
    def _register_hook(self):
        res = super()._register_hook()
        # Safety net after registry reload (e.g. zip deploy without upgrade).
        if not sql.column_exists(self._cr, self._table, 'totalvfd_convert_foreign_currency'):
            sql.create_column(
                self._cr,
                self._table,
                'totalvfd_convert_foreign_currency',
                'boolean',
            )
            self._cr.execute(
                """
                UPDATE res_company
                SET totalvfd_convert_foreign_currency = TRUE
                WHERE totalvfd_convert_foreign_currency IS NULL
                """
            )
        return res

    totalvfd_bearer_token = fields.Char(string='Bearer Token')
    totalvfd_active_business = fields.Char(string='Active Business')
    totalvfd_serial = fields.Char(string='VFD Serial')
    totalvfd_environment = fields.Selection(
        selection=[
            ('sandbox', 'Sandbox'),
            ('production', 'Production'),
        ],
        string='Environment',
        default='sandbox',
    )
    totalvfd_vat_mapping_mode = fields.Selection(
        selection=[
            ('auto', 'Automatic (from tax rate)'),
            ('manual', 'Manual (from product / tax)'),
        ],
        string='VAT Group Mapping',
        default='auto',
        required=True,
        help='Automatic: map 18%% to A, 0%% to C, other rates to default. '
             'Manual: use VAT group set on each product or sales tax.',
    )
    totalvfd_default_vat_group = fields.Char(
        string='Default VAT Group',
        default='A',
        help='Automatic mode: used for all lines when override is on, or for rates '
             'other than 18%% and 0%%. Manual mode: fallback when product/tax has no group.',
    )
    totalvfd_use_default_vat_group_all = fields.Boolean(
        string='Use Default VAT Group for All Items',
        default=False,
        help='Automatic mode only. When enabled, every line uses the default VAT group '
             'and ignores 18%% / 0%% mapping.',
    )
    totalvfd_convert_foreign_currency = fields.Boolean(
        string='Convert Foreign Currency to Company Currency',
        default=True,
        help='Total VFD accepts TZS only. When enabled, invoice and POS amounts in another '
             'currency (e.g. USD) are converted to the company currency using Odoo exchange '
             'rates on the invoice/order date before sending to the API. Set company currency to TZS.',
    )
