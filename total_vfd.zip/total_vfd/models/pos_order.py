# -*- coding: utf-8 -*-

import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _name = 'pos.order'
    _inherit = ['pos.order', 'total.vfd.mixin']

    @api.model
    def _total_vfd_prepare_orders_from_ui(self, orders):
        for order in orders:
            data = order.get('data', order)
            if 'is_fiscalised' not in data:
                config_id = data.get('config_id') or order.get('config_id')
                if config_id:
                    config = self.env['pos.config'].browse(config_id)
                    data['is_fiscalised'] = config.totalvfd_fiscalise_default

    @api.model
    def create_from_ui(self, orders, draft=False):
        self._total_vfd_prepare_orders_from_ui(orders)
        return super().create_from_ui(orders, draft=draft)

    @api.model
    def sync_from_ui(self, orders):
        self._total_vfd_prepare_orders_from_ui(orders)
        return super().sync_from_ui(orders)

    def action_pos_order_paid(self):
        res = super().action_pos_order_paid()
        self._total_vfd_fiscalise_paid_orders()
        return res

    def read_pos_data(self, data, config_id):
        """Attach fiscal receipt fields after sync (without changing core POS field loading)."""
        result = super().read_pos_data(data, config_id)
        fiscal_fields = [
            'fiscal_status',
            'totalvfd_rctvnum',
            'totalvfd_local_time',
            'totalvfd_verification_link',
            'totalvfd_fiscal_time_display',
        ]
        extra_by_id = {
            row['id']: row
            for row in self.read(fiscal_fields, load=False)
        }
        for row in result.get('pos.order', []):
            extra = extra_by_id.get(row['id'])
            if extra:
                row.update({k: extra[k] for k in fiscal_fields})
        return result

    def _generate_pos_order_invoice(self):
        """After invoicing, mirror POS fiscal receipt onto the customer invoice."""
        result = super()._generate_pos_order_invoice()
        for order in self:
            if order.account_move and order.fiscal_status == 'success':
                order._total_vfd_sync_fiscal_to_linked_invoices()
        return result

    def _total_vfd_fiscalise_paid_orders(self):
        """Fiscalise paid POS orders; errors are logged and stored on the order."""
        fiscal_orders = self.filtered(
            lambda o: o.is_fiscalised and o.state in ('paid', 'done', 'invoiced')
        )
        for order in fiscal_orders:
            try:
                order._total_vfd_fiscalise()
            except Exception as exc:
                _logger.exception(
                    'Total VFD fiscalisation failed for POS order %s: %s',
                    order.name,
                    exc,
                )
                order._total_vfd_mark_failed(str(exc))
