# -*- coding: utf-8 -*-

import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _name = 'pos.order'
    _inherit = ['pos.order', 'total.vfd.mixin']

    @api.model
    def _total_vfd_prepare_orders_from_ui(self, orders):
        for order in orders:
            data = order.get('data', order)
            if 'is_fiscalised' not in data:
                config_id = data.get('config_id') or order.get('config_id')
                if config_id:
                    config = self.env['pos.config'].browse(config_id)
                    data['is_fiscalised'] = config.totalvfd_fiscalise_default

    @api.model
    def create_from_ui(self, orders, draft=False):
        self._total_vfd_prepare_orders_from_ui(orders)
        return super().create_from_ui(orders, draft=draft)

    @api.model
    def _total_vfd_partner_id_from_ui_order(self, order):
        """Extract partner id from the POS UI sync payload."""
        data = order.get('data', order)
        partner_id = data.get('partner_id')
        if isinstance(partner_id, (list, tuple)):
            return partner_id[0] if partner_id else False
        return partner_id or False

    @api.model
    def _total_vfd_apply_partner_from_ui_payload(self, orders):
        """Ensure server partner_id matches what the cashier selected before fiscalising."""
        partner_by_uuid = {}
        for order in orders:
            data = order.get('data', order)
            uuid = data.get('uuid')
            partner_id = self._total_vfd_partner_id_from_ui_order(order)
            if uuid and partner_id:
                partner_by_uuid[uuid] = partner_id

        if not partner_by_uuid:
            return self.env['pos.order']

        pos_orders = self.search([
            ('uuid', 'in', list(partner_by_uuid)),
            ('state', 'in', ('paid', 'done', 'invoiced')),
        ])
        for pos_order in pos_orders:
            expected_id = partner_by_uuid.get(pos_order.uuid)
            if expected_id and pos_order.partner_id.id != expected_id:
                if self.env['res.partner'].browse(expected_id).exists():
                    pos_order.write({'partner_id': expected_id})
        return pos_orders

    @api.model
    def _total_vfd_fiscal_pos_sync_fields(self):
        return [
            'fiscal_status',
            'totalvfd_rctvnum',
            'totalvfd_local_time',
            'totalvfd_verification_link',
            'totalvfd_fiscal_time_display',
        ]

    def _total_vfd_merge_fiscal_into_sync_rows(self, rows, orders=None):
        """Push fiscal receipt fields into the dict returned to the POS frontend."""
        if not rows:
            return
        order_ids = [row['id'] for row in rows if row.get('id')]
        if not order_ids:
            return
        orders = orders or self.browse(order_ids)
        fields = self._total_vfd_fiscal_pos_sync_fields()
        extra_by_id = {
            row['id']: row
            for row in orders.read(fields, load=False)
        }
        for row in rows:
            extra = extra_by_id.get(row.get('id'))
            if extra:
                row.update({name: extra[name] for name in fields})

    @api.model
    def sync_from_ui(self, orders):
        self._total_vfd_prepare_orders_from_ui(orders)
        result = super().sync_from_ui(orders)
        synced_orders = self._total_vfd_apply_partner_from_ui_payload(orders)
        paid_ids = {
            row['id']
            for row in result.get('pos.order', [])
            if row.get('state') in ('paid', 'done', 'invoiced')
        }
        if paid_ids:
            fiscal_orders = synced_orders | self.browse(list(paid_ids))
            fiscal_orders._total_vfd_fiscalise_paid_orders()
            # Invoice is often created before POS fiscalisation finishes; copy receipt now.
            fiscal_orders.filtered('account_move')._total_vfd_sync_fiscal_to_linked_invoices()
            fiscal_orders.filtered('account_move').mapped(
                'account_move',
            )._total_vfd_refresh_invoice_pdf()
            # Fiscalisation runs after read_pos_data; merge so receipt QR is available.
            self._total_vfd_merge_fiscal_into_sync_rows(
                result.get('pos.order', []),
                fiscal_orders,
            )
        return result

    def action_pos_order_paid(self):
        """Fiscalisation runs after full UI sync so partner_id is saved first."""
        return super().action_pos_order_paid()

    def read_pos_data(self, data, config_id):
        """Attach fiscal receipt fields after sync (without changing core POS field loading)."""
        result = super().read_pos_data(data, config_id)
        self._total_vfd_merge_fiscal_into_sync_rows(result.get('pos.order', []), self)
        return result

    def _generate_pos_order_invoice(self):
        """
        Create/post the invoice without PDF first; PDF is generated after POS fiscalisation
        (see sync_from_ui) so the QR is included.
        """
        result = super(PosOrder, self.with_context(generate_pdf=False))._generate_pos_order_invoice()
        for order in self:
            if order.account_move and order.fiscal_status == 'success':
                order._total_vfd_sync_fiscal_to_linked_invoices()
                order.account_move._total_vfd_refresh_invoice_pdf()
        return result

    def _total_vfd_fiscalise_paid_orders(self):
        """Fiscalise paid POS orders; errors are logged and stored on the order."""
        fiscal_orders = self.filtered(
            lambda o: o.is_fiscalised and o.state in ('paid', 'done', 'invoiced')
        )
        for order in fiscal_orders:
            try:
                order._total_vfd_fiscalise()
            except Exception as exc:
                _logger.exception(
                    'Total VFD fiscalisation failed for POS order %s: %s',
                    order.name,
                    exc,
                )
                order._total_vfd_mark_failed(str(exc))
