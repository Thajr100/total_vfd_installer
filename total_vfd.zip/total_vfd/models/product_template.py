# -*- coding: utf-8 -*-

from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    totalvfd_company_vat_mode = fields.Selection(
        related='company_id.totalvfd_vat_mapping_mode',
        string='Total VFD VAT Mode',
    )
    totalvfd_vat_group = fields.Char(
        string='Total VFD VAT Group',
        help='Manual mode: VAT group for this product (e.g. A, B, C). '
             'Used when no VAT group is set on the product sales tax.',
    )


class ProductProduct(models.Model):
    _inherit = 'product.product'

    totalvfd_company_vat_mode = fields.Selection(
        related='company_id.totalvfd_vat_mapping_mode',
    )
    totalvfd_vat_group = fields.Char(
        related='product_tmpl_id.totalvfd_vat_group',
        readonly=False,
        string='Total VFD VAT Group',
    )


class AccountTax(models.Model):
    _inherit = 'account.tax'

    totalvfd_vat_group = fields.Char(
        string='Total VFD VAT Group',
        help='Manual mode: VAT group when this tax is on the invoice/POS line '
             '(e.g. A, B, C). Takes priority over the product VAT group.',
    )
