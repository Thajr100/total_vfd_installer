# -*- coding: utf-8 -*-

import json

from odoo import fields, models


class TotalVfdLog(models.Model):
    _name = 'total.vfd.log'
    _description = 'Total VFD API Log'
    _order = 'create_date desc'

    name = fields.Char(string='Reference', required=True, index=True)
    res_model = fields.Char(string='Source Model', index=True)
    res_id = fields.Integer(string='Source Record ID', index=True)
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )
    endpoint = fields.Char(string='Endpoint')
    request_headers = fields.Text(string='Request Headers')
    request_payload = fields.Text(string='Request Payload')
    response_payload = fields.Text(string='Response Payload')
    status = fields.Selection(
        selection=[
            ('success', 'Success'),
            ('failed', 'Failed'),
        ],
        string='Status',
        required=True,
    )
    error_message = fields.Text(string='Error Message')
    http_status = fields.Integer(string='HTTP Status')

    def _format_json(self, data):
        if not data:
            return ''
        if isinstance(data, str):
            return data
        return json.dumps(data, indent=2, default=str)
