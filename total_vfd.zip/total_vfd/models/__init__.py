# -*- coding: utf-8 -*-

from . import total_vfd_license
from . import total_vfd_license_grant
from . import total_vfd_log
from . import total_vfd_queue
from . import total_vfd_mixin
from . import res_company
from . import res_config_settings
from . import product_template
from . import account_move
from . import pos_config
from . import pos_order
