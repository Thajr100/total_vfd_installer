# -*- coding: utf-8 -*-

import json
import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)

MAX_RETRIES = 10


class TotalVfdQueue(models.Model):
    _name = 'total.vfd.queue'
    _description = 'Total VFD Fiscalisation Queue'
    _order = 'create_date asc'

    name = fields.Char(string='Description', required=True)
    res_model = fields.Char(string='Model', required=True, index=True)
    res_id = fields.Integer(string='Record ID', required=True, index=True)
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )
    payload = fields.Text(string='Payload', required=True)
    retry_count = fields.Integer(string='Retry Count', default=0)
    last_error = fields.Text(string='Last Error')
    status = fields.Selection(
        selection=[
            ('pending', 'Pending'),
            ('processing', 'Processing'),
            ('done', 'Done'),
            ('failed', 'Failed'),
        ],
        string='Status',
        default='pending',
        required=True,
        index=True,
    )

    @api.model
    def enqueue(self, record, payload, error_message):
        """Add or update a queue entry for retry."""
        self.env['total.vfd.license'].check_module_access()
        existing = self.search([
            ('res_model', '=', record._name),
            ('res_id', '=', record.id),
            ('status', 'in', ('pending', 'failed', 'processing')),
        ], limit=1)
        payload_text = json.dumps(payload) if isinstance(payload, dict) else payload
        values = {
            'name': f'{record._name},{record.id}',
            'res_model': record._name,
            'res_id': record.id,
            'company_id': record.company_id.id,
            'payload': payload_text,
            'last_error': error_message,
            'status': 'pending',
        }
        if existing:
            existing.write({
                'payload': payload_text,
                'last_error': error_message,
                'status': 'pending',
                'retry_count': existing.retry_count,
            })
            return existing
        return self.create(values)

    @api.model
    def _cron_retry_failed_fiscalisation(self):
        """Retry queued fiscalisation requests (every 5 minutes)."""
        if not self.env['total.vfd.license'].is_license_active():
            return
        domain = [
            ('status', 'in', ('pending', 'failed')),
            ('retry_count', '<', MAX_RETRIES),
        ]
        for queue_item in self.search(domain, limit=50):
            queue_item._process_queue_item()

    def _process_queue_item(self):
        self.ensure_one()
        if self.retry_count >= MAX_RETRIES:
            self.status = 'failed'
            return

        record = self.env[self.res_model].browse(self.res_id).exists()
        if not record:
            self.write({
                'status': 'failed',
                'last_error': 'Source record no longer exists.',
            })
            return

        if not getattr(record, 'is_fiscalised', False):
            self.write({
                'status': 'failed',
                'last_error': 'Fiscalisation disabled on source record.',
            })
            return

        self.status = 'processing'
        try:
            payload = json.loads(self.payload)
        except (json.JSONDecodeError, TypeError):
            self.write({
                'status': 'failed',
                'retry_count': self.retry_count + 1,
                'last_error': 'Invalid payload in queue.',
            })
            return

        success = record._total_vfd_send_payload(payload, from_queue=True)
        if success:
            self.write({'status': 'done', 'last_error': False})
        else:
            new_retry = self.retry_count + 1
            record.write({'totalvfd_retry_count': new_retry})
            self.write({
                'status': 'pending' if new_retry < MAX_RETRIES else 'failed',
                'retry_count': new_retry,
                'last_error': record.totalvfd_error_message,
            })
