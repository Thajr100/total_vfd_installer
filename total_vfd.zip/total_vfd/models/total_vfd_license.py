# -*- coding: utf-8 -*-

from datetime import datetime

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools import format_date

from odoo.addons.total_vfd.services.license_constants import (
    GRANT_STATE_REVOKED,
    LICENSE_STATUS_ACTIVE,
    LICENSE_STATUS_AWAITING_KEY,
    LICENSE_STATUS_EXPIRED,
    LICENSE_STATUS_INACTIVE,
    LICENSE_STATUS_INVALID,
    LICENSE_STATUS_REVOKED,
    LICENSE_WARNING_DAYS,
)
from odoo.addons.total_vfd.services.license_service import LicenseService, LicenseServiceError
from odoo.addons.total_vfd.services.license_validation_client import (
    LicenseValidationClient,
    LicenseValidationError,
)


class TotalVfdLicense(models.Model):
    _name = 'total.vfd.license'
    _description = 'Total VFD Module License'
    _rec_name = 'license_word'

    license_word = fields.Char(string='License Word', readonly=True, copy=False)
    license_key_hash = fields.Char(string='License Key Hash', readonly=True, copy=False)
    activation_date = fields.Datetime(string='Activation Date', readonly=True, copy=False)
    expiry_date = fields.Date(string='Expiry Date', readonly=True, copy=False, index=True)
    status = fields.Selection(
        selection=[
            (LICENSE_STATUS_INACTIVE, 'Inactive'),
            (LICENSE_STATUS_AWAITING_KEY, 'Awaiting License Key'),
            (LICENSE_STATUS_ACTIVE, 'Active'),
            (LICENSE_STATUS_EXPIRED, 'Expired'),
            (LICENSE_STATUS_REVOKED, 'Revoked'),
            (LICENSE_STATUS_INVALID, 'Invalid / Tampered'),
        ],
        string='Status',
        default=LICENSE_STATUS_INACTIVE,
        required=True,
        readonly=True,
        copy=False,
    )
    database_uuid = fields.Char(string='Database UUID', readonly=True, copy=False)
    integrity_seal = fields.Char(string='Integrity Seal', readonly=True, copy=False)
    grant_id = fields.Many2one(
        'total.vfd.license.grant',
        string='License Grant',
        readonly=True,
        copy=False,
        ondelete='set null',
    )
    days_until_expiry = fields.Integer(
        string='Days Until Expiry',
        compute='_compute_expiry_info',
    )
    is_expiring_soon = fields.Boolean(
        string='Expiring Soon',
        compute='_compute_expiry_info',
    )
    status_message = fields.Char(
        string='Status Message',
        compute='_compute_status_message',
    )
    warning_message = fields.Char(
        string='Warning Message',
        compute='_compute_status_message',
    )

    @api.depends('expiry_date', 'status')
    def _compute_expiry_info(self):
        today = fields.Date.context_today(self)
        for record in self:
            if record.status == LICENSE_STATUS_ACTIVE and record.expiry_date:
                delta = (record.expiry_date - today).days
                record.days_until_expiry = delta
                record.is_expiring_soon = 0 <= delta <= LICENSE_WARNING_DAYS
            else:
                record.days_until_expiry = 0
                record.is_expiring_soon = False

    @api.depends('status', 'expiry_date', 'days_until_expiry', 'is_expiring_soon', 'license_word')
    def _compute_status_message(self):
        for record in self:
            record.warning_message = False
            if record._needs_upgrade_reactivate() and record.status == LICENSE_STATUS_ACTIVE:
                record.status_message = (
                    'Upgraded to license validation server: open Activate License and paste '
                    'your vendor activation code and license key once to link this database.'
                )
            elif not record._is_validation_server_configured():
                record.status_message = (
                    'Configure the License Validation Server (URL and API key) in '
                    'Settings → Total VFD. Click Save, then Test connection, before activating.'
                )
            elif record.status == LICENSE_STATUS_AWAITING_KEY and record.license_word:
                record.status_message = (
                    f'Your License Word is "{record.license_word}". '
                    f'Tell your vendor this word only. When you receive their email, '
                    f'open Activate License and paste your Vendor Activation Code and License Key.'
                )
            elif record.status == LICENSE_STATUS_INACTIVE:
                record.status_message = (
                    'Save the license validation server settings, then your License Word '
                    'will be assigned from the server.'
                )
            elif record.status == LICENSE_STATUS_ACTIVE:
                expiry_label = format_date(self.env, record.expiry_date) if record.expiry_date else ''
                record.status_message = f'License active until {expiry_label}.'
                if record.is_expiring_soon:
                    record.warning_message = (
                        f'Your Total VFD module license expires in {record.days_until_expiry} day(s) '
                        f'on {expiry_label}. Please renew before expiry.'
                    )
            elif record.status == LICENSE_STATUS_EXPIRED:
                record.status_message = 'License has expired. Renew to continue using Total VFD.'
            elif record.status == LICENSE_STATUS_REVOKED:
                record.status_message = 'License has been revoked. Contact your vendor.'
            elif record.status == LICENSE_STATUS_INVALID:
                record.status_message = (
                    'License data is invalid or was tampered with. '
                    'Re-activate with a valid license from your vendor.'
                )
            else:
                record.status_message = ''

    @api.model
    def _is_validation_server_configured(self):
        return LicenseValidationClient.is_configured(self.env)

    @api.model
    def _require_validation_server(self):
        if not self._is_validation_server_configured():
            raise UserError(
                'License validation server is not configured.\n\n'
                'Open Settings → Total VFD and set:\n'
                '• License Validation Server URL (from your module vendor)\n'
                '• License Validation API Key (from your module vendor)\n\n'
                'The license server is not installed on this Odoo server — only URL and key. '
                'Click Save, then Test connection, before continuing with the module license.'
            )

    @api.model
    def _needs_upgrade_reactivate(self):
        return (
            self.env['ir.config_parameter'].sudo().get_param(
                'total_vfd.license.upgrade_reactivate',
            ) == '1'
        )

    @api.model
    def _clear_upgrade_reactivate(self):
        self.env['ir.config_parameter'].sudo().set_param(
            'total_vfd.license.upgrade_reactivate',
            '0',
        )

    @api.model
    def _on_validation_server_first_configured(self):
        """
        First time validation URL/key are saved: pull assign-word from license_site.
        If the server returns a different word, notify the admin.
        """
        license_record = self._get_singleton()
        icp = self.env['ir.config_parameter'].sudo()

        if license_record.status == LICENSE_STATUS_ACTIVE and self._needs_upgrade_reactivate():
            return license_record

        site_id = self._get_database_uuid()
        if not site_id:
            raise UserError(
                'Database UUID is missing. Contact your administrator '
                '(Settings → Technical → Parameters → database.uuid).'
            )

        try:
            data = self._get_validation_client().assign_word(site_id)
        except LicenseValidationError as exc:
            raise UserError(str(exc)) from exc

        server_word = data.get('base_word')
        old_word = license_record.license_word
        if server_word and old_word and server_word != old_word:
            icp.set_param(
                'total_vfd.license.word_changed_notice',
                f'Your license word is now "{server_word}" (it was "{old_word}"). '
                f'If you already sent "{old_word}" to your vendor, send them "{server_word}" instead.',
            )
        else:
            icp.set_param('total_vfd.license.word_changed_notice', '')

        if license_record.status == LICENSE_STATUS_ACTIVE:
            return license_record

        license_record.sudo().write({
            'license_word': server_word,
            'status': data.get('status', LICENSE_STATUS_AWAITING_KEY),
            'database_uuid': site_id,
            'license_key_hash': False,
            'activation_date': False,
            'expiry_date': False,
            'integrity_seal': False,
        })
        return license_record

    @api.model
    def _get_database_uuid(self):
        return self.env['ir.config_parameter'].sudo().get_param('database.uuid') or ''

    @api.model
    def _get_validation_client(self):
        self._require_validation_server()
        return LicenseValidationClient.from_env(self.env)

    def _build_license_api_payload(self):
        """License object sent to license_site (site_id = database.uuid)."""
        self.ensure_one()
        site_id = self.database_uuid or self._get_database_uuid()
        base_word = self.license_word or ''
        return {
            'site_id': site_id,
            'base_word': base_word,
            'activation_phrase': (
                LicenseService.verification_word(base_word) if base_word else ''
            ),
            'status': self.status,
            'license_key_hash': self.license_key_hash or '',
            'expiry_date': self.expiry_date.isoformat() if self.expiry_date else '',
            'integrity_seal': self.integrity_seal or '',
        }

    def _apply_api_license(self, api_license):
        """Persist license fields returned by license_site activate/check."""
        self.ensure_one()
        activation_date = api_license.get('activation_date')
        activation_dt = False
        if activation_date:
            try:
                activation_dt = fields.Datetime.to_datetime(activation_date)
            except (ValueError, TypeError):
                activation_dt = datetime.strptime(activation_date[:10], '%Y-%m-%d')

        expiry = api_license.get('expiry_date') or False
        self.sudo().write({
            'license_word': api_license.get('base_word') or self.license_word,
            'license_key_hash': api_license.get('license_key_hash'),
            'status': api_license.get('status', LICENSE_STATUS_ACTIVE),
            'expiry_date': expiry,
            'integrity_seal': api_license.get('integrity_seal'),
            'database_uuid': api_license.get('site_id') or self._get_database_uuid(),
            'activation_date': activation_dt,
            'grant_id': False,
        })

    @api.model
    def _get_singleton(self):
        try:
            license_record = self.env.ref('total_vfd.total_vfd_license_default')
        except ValueError:
            license_record = self.browse()
        if not license_record.exists():
            license_record = self.search([], limit=1, order='id')
        if not license_record:
            license_record = self.sudo().create({
                'status': LICENSE_STATUS_INACTIVE,
                'database_uuid': self._get_database_uuid(),
            })
        return license_record

    @api.model
    def assign_license_word(self):
        """Assign word via license_site POST /api/v1/license/assign-word."""
        self._require_validation_server()
        license_record = self._get_singleton()
        if license_record.status == LICENSE_STATUS_ACTIVE:
            return license_record
        if license_record.license_word and license_record.status == LICENSE_STATUS_AWAITING_KEY:
            return license_record

        site_id = self._get_database_uuid()
        if not site_id:
            raise UserError(
                'Database UUID is missing. Contact your administrator '
                '(Settings → Technical → Parameters → database.uuid).'
            )

        try:
            data = self._get_validation_client().assign_word(site_id)
        except LicenseValidationError as exc:
            raise UserError(str(exc)) from exc

        license_record.sudo().write({
            'license_word': data.get('base_word'),
            'status': data.get('status', LICENSE_STATUS_AWAITING_KEY),
            'database_uuid': site_id,
            'license_key_hash': False,
            'activation_date': False,
            'expiry_date': False,
            'integrity_seal': False,
        })
        return license_record

    def _sync_expiry_status(self):
        self.ensure_one()
        today = fields.Date.context_today(self)
        if self.status == LICENSE_STATUS_ACTIVE and self.expiry_date and self.expiry_date < today:
            self.sudo().write({'status': LICENSE_STATUS_EXPIRED})

    @api.model
    def _cron_check_license(self):
        if not self._is_validation_server_configured():
            return
        license_record = self._get_singleton()
        if license_record.status != LICENSE_STATUS_ACTIVE:
            return
        icp = self.env['ir.config_parameter'].sudo()
        try:
            result = self._get_validation_client().check(
                license_record._build_license_api_payload(),
            )
            icp.set_param('total_vfd.license.warning', result.get('warning') or '')
        except LicenseValidationError:
            icp.set_param('total_vfd.license.warning', '')
            license_record._sync_expiry_status()

    @api.model
    def check_module_access(self):
        """Raise UserError if the module must not be used."""
        self._require_validation_server()
        license_record = self._get_singleton()
        if not license_record.license_word:
            license_record.assign_license_word()

        if license_record.status == LICENSE_STATUS_ACTIVE:
            if self._needs_upgrade_reactivate():
                raise UserError(
                    'This database was upgraded to use the central license validation server.\n\n'
                    'Open Settings → Total VFD → Activate License and paste your '
                    'Vendor Activation Code and License Key once (from your vendor email). '
                    'You can use the same pair you used before the upgrade.'
                )
            try:
                result = self._get_validation_client().check(
                    license_record._build_license_api_payload(),
                )
            except LicenseValidationError as exc:
                license_record._sync_expiry_status()
                raise UserError(
                    f'{exc}\n\n'
                    'If you upgraded recently, open Activate License and paste your '
                    'vendor code and license key again.'
                ) from exc

            icp = self.env['ir.config_parameter'].sudo()
            icp.set_param('total_vfd.license.warning', result.get('warning') or '')
            license_record._sync_expiry_status()
            if license_record.status != LICENSE_STATUS_ACTIVE:
                raise UserError(
                    'Your Total VFD module license has expired. '
                    'Open Settings → Total VFD → License to renew.'
                )
            return license_record

        messages = {
            LICENSE_STATUS_AWAITING_KEY: (
                f'Your License Word is "{license_record.license_word}". '
                f'Tell your vendor this word. Activate with the Vendor Activation Code '
                f'and License Key from your vendor email.'
            ),
            LICENSE_STATUS_INACTIVE: (
                'Total VFD requires a valid module license. '
                'Open Settings → Total VFD to configure the validation server and activate.'
            ),
            LICENSE_STATUS_EXPIRED: (
                'Your Total VFD module license has expired. '
                'Open Settings → Total VFD → License to renew.'
            ),
            LICENSE_STATUS_REVOKED: (
                'Your Total VFD module license has been revoked. Contact your vendor.'
            ),
            LICENSE_STATUS_INVALID: (
                'Your Total VFD module license is invalid or was tampered with. '
                'Re-activate with a valid license from your vendor.'
            ),
        }
        raise UserError(messages.get(license_record.status, messages[LICENSE_STATUS_INACTIVE]))

    @api.model
    def is_license_active(self):
        try:
            self.check_module_access()
            return True
        except UserError:
            return False

    @api.model
    def activate_license(self, license_key, verification_token=None, renew=False):
        """Activate or renew via license_site POST /api/v1/license/activate."""
        self._require_validation_server()
        license_record = self._get_singleton()
        if license_record.status == LICENSE_STATUS_REVOKED:
            raise UserError('This license has been revoked and cannot be activated.')

        if not license_record.license_word:
            license_record.assign_license_word()

        if not license_key or not str(license_key).strip():
            raise UserError('License Key is required (format: XXXXXX-XXXXXX-XXXXXX-XXXXXX).')

        site_id = self._get_database_uuid()
        vendor_code = LicenseService.normalize_verification_token(verification_token) or None
        if not renew and not vendor_code:
            icp = self.env['ir.config_parameter'].sudo()
            vendor_code = LicenseService.normalize_verification_token(
                icp.get_param('total_vfd.license.pending_verification_token') or '',
            ) or None

        if not renew and not vendor_code:
            raise UserError(
                'Paste your Vendor Activation Code from the vendor email.'
            )

        try:
            result = self._get_validation_client().activate(
                site_id,
                license_key,
                license_record._build_license_api_payload(),
                vendor_code=vendor_code,
            )
        except LicenseValidationError as exc:
            raise UserError(str(exc)) from exc

        api_license = result.get('license')
        if not api_license:
            raise UserError('License server returned an empty license.')

        license_record._apply_api_license(api_license)
        icp = self.env['ir.config_parameter'].sudo()
        icp.set_param('total_vfd.license.pending_verification_token', '')
        icp.set_param('total_vfd.license.warning', '')
        icp.set_param('total_vfd.license.word_changed_notice', '')
        self._clear_upgrade_reactivate()
        return license_record

    @api.model
    def is_vendor_activation_code_saved(self):
        token = self.env['ir.config_parameter'].sudo().get_param(
            'total_vfd.license.pending_verification_token',
        )
        return bool(token and str(token).strip())

    @api.model
    def get_vendor_message_for_customer(self):
        """Text the customer can send to their vendor."""
        self._require_validation_server()
        lic = self._get_singleton()
        if not lic.license_word:
            lic.assign_license_word()
        db_uuid = self._get_database_uuid()
        lines = [
            f'My Total VFD License Word is: {lic.license_word}',
            f'Site ID (Database UUID): {db_uuid}',
            f'Validation server: {self.env["ir.config_parameter"].sudo().get_param("total_vfd.license_validation_url")}',
        ]
        return '\n'.join(lines)

    @api.model
    def action_register_vendor_token(self, verification_token):
        if not verification_token or not str(verification_token).strip():
            raise UserError('Paste the Vendor Activation Code from your vendor email.')
        try:
            normalized = LicenseService.normalize_verification_token(verification_token)
            LicenseService.decode_verification_token(normalized)
        except LicenseServiceError as exc:
            raise UserError(str(exc)) from exc
        self.env['ir.config_parameter'].sudo().set_param(
            'total_vfd.license.pending_verification_token',
            normalized,
        )
        return True

    def action_show_vendor_message(self):
        message = self.get_vendor_message_for_customer()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Message for your vendor',
                'message': message,
                'type': 'info',
                'sticky': True,
            },
        }

    def action_revoke(self):
        for record in self:
            record.sudo().write({'status': LICENSE_STATUS_REVOKED})
            if record.grant_id and record.grant_id.state != GRANT_STATE_REVOKED:
                record.grant_id.sudo().write({'state': GRANT_STATE_REVOKED})

    def action_open_activate_wizard(self):
        self._require_validation_server()
        self.assign_license_word()
        lic = self._get_singleton()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Activate Total VFD License',
            'res_model': 'total.vfd.license.activate.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_renew': False,
                'default_license_word_base': lic.license_word,
            },
        }

    def action_open_renew_wizard(self):
        self._require_validation_server()
        lic = self._get_singleton()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Renew Total VFD License',
            'res_model': 'total.vfd.license.activate.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_renew': True,
                'default_license_word_base': lic.license_word,
            },
        }

    def action_register_vendor_code_only(self):
        return self.action_open_activate_wizard()
