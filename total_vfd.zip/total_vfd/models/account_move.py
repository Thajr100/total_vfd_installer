# -*- coding: utf-8 -*-

import logging

from odoo import _, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _name = 'account.move'
    _inherit = ['account.move', 'total.vfd.mixin']

    def action_sync_total_vfd_from_pos(self):
        """Copy fiscal receipt from linked POS order (for invoices left pending)."""
        synced = 0
        for move in self:
            if move._total_vfd_try_sync_from_pos():
                synced += 1
                continue
            pos_orders = move.pos_order_ids.filtered('is_fiscalised')
            if not pos_orders:
                raise UserError(_('This invoice is not linked to a POS order.'))
            pos_ref = pos_orders[0].pos_reference or pos_orders[0].name
            raise UserError(
                _('Linked POS order %s is not fiscalised successfully yet.') % pos_ref
            )
        if synced:
            return self._total_vfd_notification(
                _('Fiscal data copied from the POS order.'),
                notif_type='success',
            )
        return True

    def _post(self, soft=True):
        """Fiscalise after posting (covers all posting paths, including batch post)."""
        posted = super()._post(soft=soft)
        posted._total_vfd_fiscalise_posted_moves()
        return posted

    def _total_vfd_apply_fiscal_from_pos_order(self, pos_order):
        """
        Mirror fiscal data from an already fiscalised POS order.
        Avoids a second API call (POS and invoice use different reference numbers).
        """
        self.ensure_one()
        pos_order.ensure_one()
        if pos_order.fiscal_status != 'success' or not pos_order.totalvfd_sent:
            return False
        values = pos_order._total_vfd_get_fiscal_sync_values()
        pos_ref = pos_order.pos_reference or pos_order.name
        notice = values.get('totalvfd_api_message') or False
        sync_note = f'Fiscal receipt from POS order {pos_ref}.'
        values['totalvfd_api_message'] = f'{notice} {sync_note}'.strip() if notice else sync_note
        self.write(values)
        _logger.info(
            'Copied Total VFD fiscal data from POS order %s to invoice %s',
            pos_order.id,
            self.id,
        )
        return True

    def _total_vfd_try_sync_from_pos(self):
        """If this invoice belongs to a fiscalised POS order, copy its receipt."""
        self.ensure_one()
        if self.move_type != 'out_invoice':
            return False
        pos_order = self.pos_order_ids.filtered(
            lambda o: o.is_fiscalised and o.fiscal_status == 'success' and o.totalvfd_sent
        )[:1]
        if not pos_order:
            return False
        return self._total_vfd_apply_fiscal_from_pos_order(pos_order)

    def _total_vfd_fiscalise_posted_moves(self):
        """Fiscalise posted customer invoices only; never credit notes."""
        for move in self:
            if move.move_type == 'out_invoice' and move.state == 'posted':
                move._total_vfd_try_sync_from_pos()

        fiscal_moves = self.filtered(
            lambda m: (
                m.is_fiscalised
                and m.state == 'posted'
                and m.move_type == 'out_invoice'
            )
        )
        for move in fiscal_moves:
            if move.fiscal_status == 'success' and move.totalvfd_sent:
                continue
            if move._total_vfd_try_sync_from_pos():
                continue
            try:
                move._total_vfd_fiscalise()
            except Exception as exc:
                _logger.exception(
                    'Total VFD fiscalisation failed for invoice %s: %s',
                    move.name,
                    exc,
                )
                move._total_vfd_mark_failed(str(exc))
