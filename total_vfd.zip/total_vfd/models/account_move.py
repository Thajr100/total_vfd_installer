# -*- coding: utf-8 -*-

import logging
from urllib.parse import quote

from odoo import api, fields, models
from odoo.exceptions import UserError

from odoo.addons.total_vfd.services.qr_generator import QrGenerator

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _name = 'account.move'
    _inherit = ['account.move', 'total.vfd.mixin']

    totalvfd_show_fiscal_on_report = fields.Boolean(
        compute='_compute_totalvfd_report_display',
        compute_sudo=True,
    )
    totalvfd_report_qr_code = fields.Binary(
        compute='_compute_totalvfd_report_display',
        compute_sudo=True,
    )
    totalvfd_report_rctvnum = fields.Char(
        compute='_compute_totalvfd_report_display',
        compute_sudo=True,
    )
    totalvfd_report_fiscal_time = fields.Char(
        compute='_compute_totalvfd_report_display',
        compute_sudo=True,
    )
    totalvfd_report_verification_link = fields.Char(
        compute='_compute_totalvfd_report_display',
        compute_sudo=True,
    )
    totalvfd_report_barcode_url = fields.Char(
        compute='_compute_totalvfd_report_display',
        compute_sudo=True,
    )

    @api.depends(
        'move_type', 'state',
        'fiscal_status', 'totalvfd_sent', 'totalvfd_qr_code', 'totalvfd_rctvnum',
        'totalvfd_verification_link', 'totalvfd_local_time', 'totalvfd_fiscal_time_display',
        'pos_order_ids.fiscal_status', 'pos_order_ids.totalvfd_sent',
        'pos_order_ids.totalvfd_qr_code', 'pos_order_ids.totalvfd_rctvnum',
        'pos_order_ids.totalvfd_verification_link', 'pos_order_ids.totalvfd_local_time',
        'pos_order_ids.totalvfd_fiscal_time_display',
    )
    def _compute_totalvfd_report_display(self):
        """Invoice PDF: use invoice fiscal data, or fall back to linked POS receipt."""
        for move in self:
            move.totalvfd_show_fiscal_on_report = False
            move.totalvfd_report_qr_code = False
            move.totalvfd_report_rctvnum = False
            move.totalvfd_report_fiscal_time = False
            move.totalvfd_report_verification_link = False
            move.totalvfd_report_barcode_url = False
            if move.move_type != 'out_invoice' or move.state != 'posted':
                continue

            if move.fiscal_status == 'success' and move.totalvfd_sent:
                src = move
            else:
                src = move.sudo().pos_order_ids.filtered(
                    lambda o: o.fiscal_status == 'success' and o.totalvfd_sent
                )[:1]
                if not src:
                    continue

            move.totalvfd_show_fiscal_on_report = True
            move.totalvfd_report_rctvnum = src.totalvfd_rctvnum or ''
            move.totalvfd_report_fiscal_time = (
                src.totalvfd_fiscal_time_display or src.totalvfd_local_time or ''
            )
            link = src.totalvfd_verification_link or ''
            move.totalvfd_report_verification_link = link
            if link:
                move.totalvfd_report_barcode_url = (
                    '/report/barcode/QR/%s?width=80&height=80' % quote(link, safe='')
                )
            qr = src.totalvfd_qr_code
            if not qr and link:
                qr = QrGenerator.generate_for_binary_field(link)
            move.totalvfd_report_qr_code = qr

    def _total_vfd_refresh_invoice_pdf(self):
        """Regenerate invoice PDF after POS fiscal data is copied (first PDF was too early)."""
        for move in self:
            if move.move_type != 'out_invoice' or move.state != 'posted':
                continue
            move._total_vfd_try_sync_from_pos()
            has_fiscal = (
                move.fiscal_status == 'success' and move.totalvfd_sent
            ) or bool(move.sudo().pos_order_ids.filtered(
                lambda o: o.fiscal_status == 'success' and o.totalvfd_sent
            ))
            if not has_fiscal:
                continue
            try:
                move.sudo().with_context(
                    generate_pdf=True,
                    skip_invoice_sync=True,
                )._generate_and_send()
            except Exception as exc:
                _logger.warning(
                    'Could not regenerate invoice PDF for %s: %s',
                    move.name,
                    exc,
                )

    def action_sync_total_vfd_from_pos(self):
        """Copy fiscal receipt from linked POS order (for invoices left pending)."""
        synced = 0
        for move in self:
            if move._total_vfd_try_sync_from_pos():
                synced += 1
                continue
            pos_orders = move.pos_order_ids.filtered('is_fiscalised')
            if not pos_orders:
                raise UserError(_('This invoice is not linked to a POS order.'))
            pos_ref = pos_orders[0].pos_reference or pos_orders[0].name
            raise UserError(
                _('Linked POS order %s is not fiscalised successfully yet.') % pos_ref
            )
        if synced:
            return self._total_vfd_notification(
                _('Fiscal data copied from the POS order.'),
                notif_type='success',
            )
        return True

    def _post(self, soft=True):
        """Fiscalise after posting (covers all posting paths, including batch post)."""
        posted = super()._post(soft=soft)
        posted._total_vfd_fiscalise_posted_moves()
        return posted

    def _total_vfd_apply_fiscal_from_pos_order(self, pos_order):
        """
        Mirror fiscal data from an already fiscalised POS order.
        Avoids a second API call (POS and invoice use different reference numbers).
        """
        self.ensure_one()
        pos_order.ensure_one()
        if pos_order.fiscal_status != 'success' or not pos_order.totalvfd_sent:
            return False
        values = pos_order._total_vfd_get_fiscal_sync_values()
        pos_ref = pos_order.pos_reference or pos_order.name
        notice = values.get('totalvfd_api_message') or False
        sync_note = f'Fiscal receipt from POS order {pos_ref}.'
        values['totalvfd_api_message'] = f'{notice} {sync_note}'.strip() if notice else sync_note
        self.write(values)
        _logger.info(
            'Copied Total VFD fiscal data from POS order %s to invoice %s',
            pos_order.id,
            self.id,
        )
        return True

    def _total_vfd_try_sync_from_pos(self):
        """If this invoice belongs to a fiscalised POS order, copy its receipt."""
        self.ensure_one()
        if self.move_type != 'out_invoice':
            return False
        pos_order = self.pos_order_ids.filtered(
            lambda o: o.fiscal_status == 'success' and o.totalvfd_sent
        )[:1]
        if not pos_order:
            return False
        return self._total_vfd_apply_fiscal_from_pos_order(pos_order)

    def _total_vfd_fiscalise_posted_moves(self):
        """Fiscalise posted customer invoices only; never credit notes."""
        for move in self:
            if move.move_type == 'out_invoice' and move.state == 'posted':
                move._total_vfd_try_sync_from_pos()

        fiscal_moves = self.filtered(
            lambda m: (
                m.is_fiscalised
                and m.state == 'posted'
                and m.move_type == 'out_invoice'
            )
        )
        for move in fiscal_moves:
            if move.fiscal_status == 'success' and move.totalvfd_sent:
                continue
            if move._total_vfd_try_sync_from_pos():
                continue
            try:
                move._total_vfd_fiscalise()
            except Exception as exc:
                _logger.exception(
                    'Total VFD fiscalisation failed for invoice %s: %s',
                    move.name,
                    exc,
                )
                move._total_vfd_mark_failed(str(exc))
