# -*- coding: utf-8 -*-

import json
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

from odoo.addons.total_vfd.services.payload_builder import PayloadBuilder
from odoo.addons.total_vfd.services.qr_generator import QrGenerator
from odoo.addons.total_vfd.services.response_parser import TotalVfdResponseParser
from odoo.addons.total_vfd.services.totalvfd_api import TotalVfdApi, TotalVfdApiError

_logger = logging.getLogger(__name__)


class TotalVfdMixin(models.AbstractModel):
    _name = 'total.vfd.mixin'
    _description = 'Total VFD Fiscalisation Mixin'

    is_fiscalised = fields.Boolean(
        string='Fiscalise with Total VFD',
        default=False,
        copy=False,
    )
    fiscal_status = fields.Selection(
        selection=[
            ('pending', 'Pending'),
            ('success', 'Success'),
            ('failed', 'Failed'),
        ],
        string='Fiscal Status',
        default='pending',
        copy=False,
        readonly=True,
    )
    totalvfd_rctvnum = fields.Char(string='Fiscal Receipt Number', copy=False, readonly=True)
    totalvfd_verification_link = fields.Char(string='Verification Link', copy=False, readonly=True)
    totalvfd_local_time = fields.Char(string='Fiscal Date & Time', copy=False, readonly=True)
    totalvfd_local_date = fields.Char(string='Fiscal Date', copy=False, readonly=True)
    totalvfd_rctnum = fields.Char(string='RCT Number', copy=False, readonly=True)
    totalvfd_gc = fields.Char(string='GC Number', copy=False, readonly=True)
    totalvfd_z_number = fields.Char(string='Z Number', copy=False, readonly=True)
    totalvfd_qr_code = fields.Binary(string='QR Code', copy=False, readonly=True, attachment=True)
    totalvfd_payload = fields.Text(string='Request Payload', copy=False, readonly=True)
    totalvfd_response = fields.Text(string='API Response', copy=False, readonly=True)
    totalvfd_error_message = fields.Text(
        string='Fiscal Error',
        copy=False,
        readonly=True,
        help='Shown when fiscalisation fails. Cleared on success.',
    )
    totalvfd_api_message = fields.Char(
        string='API Notice',
        copy=False,
        readonly=True,
        help='Information from the API (e.g. duplicate reference recovered).',
    )
    totalvfd_sent = fields.Boolean(string='Sent to Total VFD', default=False, copy=False, readonly=True)
    totalvfd_retry_count = fields.Integer(string='Retry Count', default=0, copy=False, readonly=True)
    # Odoo 18 forbids @api.depends('id') on compute methods — no depends decorator here.
    totalvfd_log_count = fields.Integer(compute='_compute_totalvfd_log_count')
    totalvfd_fiscal_time_display = fields.Char(
        string='Fiscal Time (display)',
        compute='_compute_totalvfd_fiscal_time_display',
    )

    def _compute_totalvfd_log_count(self):
        log_model = self.env['total.vfd.log']
        for record in self:
            if not record.id:
                record.totalvfd_log_count = 0
                continue
            record.totalvfd_log_count = log_model.search_count([
                ('res_model', '=', record._name),
                ('res_id', '=', record.id),
            ])

    def _compute_totalvfd_fiscal_time_display(self):
        for record in self:
            stamp = record.totalvfd_local_time or ''
            record.totalvfd_fiscal_time_display = (
                stamp.split(' ', 1)[-1] if ' ' in stamp else stamp
            )

    def action_open_totalvfd_logs(self):
        self.ensure_one()
        return {
            'name': 'Fiscal Logs',
            'type': 'ir.actions.act_window',
            'res_model': 'total.vfd.log',
            'view_mode': 'list,form',
            'domain': [('res_model', '=', self._name), ('res_id', '=', self.id)],
            'context': {'default_res_model': self._name, 'default_res_id': self.id},
        }

    def action_fiscalise_total_vfd(self):
        """Manual fiscalisation trigger."""
        for record in self:
            if not record.is_fiscalised:
                raise UserError('Enable "Fiscalise with Total VFD" on this document first.')
            ok = record._total_vfd_fiscalise(force=True)
            if not ok and record.totalvfd_error_message:
                raise UserError(record.totalvfd_error_message)
            if ok and record.totalvfd_api_message:
                return record._total_vfd_notification(
                    record.totalvfd_api_message,
                    notif_type='warning',
                )
        return True

    def action_retry_total_vfd_fiscalisation(self):
        """Re-queue fiscalisation for manual retry."""
        return self.action_fiscalise_total_vfd()

    def _total_vfd_notification(self, message, notif_type='success', title='Total VFD'):
        self.ensure_one()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': title,
                'message': message,
                'type': notif_type,
                'sticky': notif_type in ('danger', 'warning'),
            },
        }

    def _total_vfd_get_company(self):
        self.ensure_one()
        return self.company_id

    @api.model
    def _total_vfd_fiscal_sync_field_names(self):
        """Fiscal result fields copied from a fiscalised POS order to its invoice."""
        return [
            'fiscal_status',
            'totalvfd_sent',
            'totalvfd_rctvnum',
            'totalvfd_verification_link',
            'totalvfd_local_time',
            'totalvfd_local_date',
            'totalvfd_rctnum',
            'totalvfd_gc',
            'totalvfd_z_number',
            'totalvfd_qr_code',
            'totalvfd_payload',
            'totalvfd_response',
            'totalvfd_error_message',
            'totalvfd_api_message',
            'totalvfd_retry_count',
        ]

    def _total_vfd_get_fiscal_sync_values(self):
        """Values to mirror onto a linked customer invoice (no second API call)."""
        self.ensure_one()
        names = self._total_vfd_fiscal_sync_field_names()
        values = {name: self[name] for name in names}
        values['is_fiscalised'] = bool(self.is_fiscalised)
        return values

    def _total_vfd_sync_fiscal_to_linked_invoices(self):
        """Copy POS fiscal receipt onto linked account.move records."""
        if self._name != 'pos.order':
            return
        for order in self:
            move = order.account_move
            if not move:
                continue
            move._total_vfd_apply_fiscal_from_pos_order(order)

    def _total_vfd_build_payload(self):
        self.ensure_one()
        company = self._total_vfd_get_company()
        builder = PayloadBuilder(self.env, company)
        if self._name == 'account.move':
            return builder.build_from_move(self)
        if self._name == 'pos.order':
            return builder.build_from_pos_order(self)
        raise ValueError(f'Unsupported model for fiscalisation: {self._name}')

    def _total_vfd_assert_module_license(self):
        """Block fiscalisation when the module license is missing or invalid."""
        self.env['total.vfd.license'].check_module_access()

    def _total_vfd_fiscalise(self, force=False):
        """Build payload and send to Total VFD API."""
        self.ensure_one()
        self._total_vfd_assert_module_license()
        if not self.is_fiscalised:
            return False
        if self.fiscal_status == 'success' and self.totalvfd_sent and not force:
            return True

        try:
            payload = self._total_vfd_build_payload()
        except Exception as exc:
            _logger.exception('Payload build failed for %s %s', self._name, self.id)
            self._total_vfd_mark_failed(str(exc), payload=None)
            return False

        return self._total_vfd_send_payload(payload, from_queue=False)

    def _total_vfd_send_payload(self, payload, from_queue=False):
        self.ensure_one()
        self._total_vfd_assert_module_license()
        company = self._total_vfd_get_company()
        payload_text = json.dumps(payload, indent=2, default=str)

        self.write({
            'fiscal_status': 'pending',
            'totalvfd_payload': payload_text,
            'totalvfd_error_message': False,
            'totalvfd_api_message': False,
        })

        api_client = None
        try:
            api_client = TotalVfdApi(company)
            result = api_client.send_receipt(payload)
        except TotalVfdApiError as exc:
            _logger.warning(
                'Total VFD API error for %s %s: %s',
                self._name, self.id, exc,
            )
            endpoint = api_client.endpoint if api_client else ''
            self._total_vfd_mark_failed(
                str(exc),
                payload=payload,
                log_values={
                    'endpoint': endpoint,
                    'response': exc.response_body,
                    'http_status': exc.status_code,
                },
            )
            return False
        except Exception as exc:
            _logger.exception('Unexpected Total VFD error for %s %s', self._name, self.id)
            self._total_vfd_mark_failed(str(exc), payload=payload)
            return False

        fiscal_body = result.get('response') or {}
        full_response = result.get('full_response') or fiscal_body
        self._total_vfd_apply_success(
            fiscal_body,
            full_response=full_response,
            api_message=result.get('api_message'),
            is_duplicate=result.get('is_duplicate'),
        )
        self._total_vfd_create_log(
            name=payload.get('referenceNumber', self.display_name),
            status='success',
            payload=payload,
            headers=result.get('headers'),
            endpoint=result.get('endpoint'),
            response=full_response,
            http_status=result.get('status_code'),
            error_message=result.get('api_message') if result.get('is_duplicate') else None,
        )
        return True

    def _total_vfd_apply_success(self, fiscal_body, full_response=None, api_message=None, is_duplicate=False):
        self.ensure_one()
        fields_map = TotalVfdResponseParser.parse_fiscal_fields(fiscal_body)
        verification_link = fields_map.get('totalvfd_verification_link') or ''
        qr_data = QrGenerator.generate_for_binary_field(verification_link)

        notice = api_message or ''
        if is_duplicate and notice:
            notice = notice
        elif is_duplicate:
            notice = 'Reference number already used; existing fiscal receipt applied.'

        stored_response = full_response if full_response is not None else fiscal_body

        self.write({
            'fiscal_status': 'success',
            'totalvfd_sent': True,
            'totalvfd_rctvnum': fields_map.get('totalvfd_rctvnum', ''),
            'totalvfd_verification_link': verification_link,
            'totalvfd_local_time': fields_map.get('totalvfd_local_time', ''),
            'totalvfd_local_date': fields_map.get('totalvfd_local_date', ''),
            'totalvfd_rctnum': fields_map.get('totalvfd_rctnum', ''),
            'totalvfd_gc': fields_map.get('totalvfd_gc', ''),
            'totalvfd_z_number': fields_map.get('totalvfd_z_number', ''),
            'totalvfd_qr_code': qr_data,
            'totalvfd_response': json.dumps(stored_response, indent=2, default=str),
            'totalvfd_error_message': False,
            'totalvfd_api_message': notice or False,
            'totalvfd_retry_count': 0,
        })
        if self._name == 'pos.order':
            self._total_vfd_sync_fiscal_to_linked_invoices()

    def _total_vfd_mark_failed(self, error_message, payload=None, log_values=None):
        self.ensure_one()
        retry_count = self.totalvfd_retry_count + 1
        values = {
            'fiscal_status': 'failed',
            'totalvfd_error_message': error_message,
            'totalvfd_api_message': False,
            'totalvfd_retry_count': retry_count,
        }
        if payload:
            values['totalvfd_payload'] = json.dumps(payload, indent=2, default=str)
        self.write(values)

        queue_payload = payload
        if queue_payload is None:
            try:
                queue_payload = self._total_vfd_build_payload()
            except Exception:
                queue_payload = None
        if queue_payload:
            self.env['total.vfd.queue'].enqueue(self, queue_payload, error_message)

        log_vals = log_values or {}
        self._total_vfd_create_log(
            name=(payload or {}).get('referenceNumber', self.display_name),
            status='failed',
            payload=payload or {},
            headers=log_vals.get('headers'),
            endpoint=log_vals.get('endpoint', ''),
            response=log_vals.get('response'),
            error_message=error_message,
            http_status=log_vals.get('http_status'),
        )

    def _total_vfd_create_log(
        self,
        name,
        status,
        payload,
        headers=None,
        endpoint='',
        response=None,
        error_message=None,
        http_status=None,
    ):
        self.ensure_one()
        log_model = self.env['total.vfd.log']
        return log_model.create({
            'name': name,
            'res_model': self._name,
            'res_id': self.id,
            'company_id': self._total_vfd_get_company().id,
            'endpoint': endpoint,
            'request_headers': json.dumps(headers, indent=2, default=str) if headers else '',
            'request_payload': json.dumps(payload, indent=2, default=str) if payload else '',
            'response_payload': json.dumps(response, indent=2, default=str) if response else '',
            'status': status,
            'error_message': error_message,
            'http_status': http_status or 0,
        })
