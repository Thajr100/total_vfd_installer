# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import UserError

from odoo.addons.total_vfd.services.dependency_check import (
    qr_install_command,
    qr_libraries_available,
)
from odoo.addons.total_vfd.services.license_constants import (
    LICENSE_STATUS_ACTIVE,
    LICENSE_STATUS_AWAITING_KEY,
)
from odoo.addons.total_vfd.services.license_validation_client import (
    LicenseValidationClient,
    LicenseValidationError,
)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    totalvfd_license_validation_url = fields.Char(
        string='License Validation Server URL',
        config_parameter='total_vfd.license_validation_url',
        help='Vendor license validation server URL (separate deployment, not on this Odoo server).',
    )
    totalvfd_license_validation_api_key = fields.Char(
        string='License Validation API Key',
        config_parameter='total_vfd.license_validation_api_key',
        help='API key from your module vendor for the license validation server.',
    )
    totalvfd_license_validation_configured = fields.Boolean(
        compute='_compute_totalvfd_license_validation',
    )
    totalvfd_qr_libraries_available = fields.Boolean(
        compute='_compute_totalvfd_qr_libraries',
    )
    totalvfd_qr_libraries_message = fields.Char(
        compute='_compute_totalvfd_qr_libraries',
    )

    totalvfd_bearer_token = fields.Char(
        related='company_id.totalvfd_bearer_token',
        readonly=False,
    )
    totalvfd_active_business = fields.Char(
        related='company_id.totalvfd_active_business',
        readonly=False,
    )
    totalvfd_serial = fields.Char(
        related='company_id.totalvfd_serial',
        readonly=False,
    )
    totalvfd_environment = fields.Selection(
        related='company_id.totalvfd_environment',
        readonly=False,
    )
    totalvfd_vat_mapping_mode = fields.Selection(
        related='company_id.totalvfd_vat_mapping_mode',
        readonly=False,
    )
    totalvfd_default_vat_group = fields.Char(
        related='company_id.totalvfd_default_vat_group',
        readonly=False,
    )
    totalvfd_use_default_vat_group_all = fields.Boolean(
        related='company_id.totalvfd_use_default_vat_group_all',
        readonly=False,
    )
    totalvfd_convert_foreign_currency = fields.Boolean(
        related='company_id.totalvfd_convert_foreign_currency',
        readonly=False,
    )

    totalvfd_module_license_awaiting_key = fields.Boolean(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_status = fields.Selection(
        selection=[
            ('inactive', 'Inactive'),
            ('awaiting_key', 'Awaiting License Key'),
            ('active', 'Active'),
            ('expired', 'Expired'),
            ('revoked', 'Revoked'),
            ('invalid', 'Invalid / Tampered'),
        ],
        string='Module License Status',
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_word = fields.Char(
        string='License Word',
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_database_uuid = fields.Char(
        string='Database ID',
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_vendor_message = fields.Text(
        string='Message for Vendor',
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_step1_done = fields.Boolean(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_step2_done = fields.Boolean(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_step3_done = fields.Boolean(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_expiry = fields.Date(
        string='License Expiry',
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_days_remaining = fields.Integer(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_message = fields.Char(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_warning = fields.Char(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_active = fields.Boolean(
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_upgrade_reactivate = fields.Boolean(
        string='Upgrade — re-activate required',
        compute='_compute_totalvfd_module_license',
    )
    totalvfd_module_license_word_changed_notice = fields.Char(
        compute='_compute_totalvfd_module_license',
    )

    def set_values(self):
        icp = self.env['ir.config_parameter'].sudo()
        was_configured = icp.get_param('total_vfd.license.validation_was_configured') == '1'
        res = super().set_values()
        if LicenseValidationClient.is_configured(self.env):
            icp.set_param('total_vfd.license.validation_was_configured', '1')
            if not was_configured:
                try:
                    self.env['total.vfd.license'].sudo()._on_validation_server_first_configured()
                except UserError:
                    pass
        return res

    @api.depends('totalvfd_license_validation_url', 'totalvfd_license_validation_api_key')
    def _compute_totalvfd_license_validation(self):
        for settings in self:
            settings.totalvfd_license_validation_configured = (
                LicenseValidationClient.is_configured(settings.env)
            )

    def _compute_totalvfd_qr_libraries(self):
        available = qr_libraries_available()
        message = False
        if not available:
            message = (
                'QR code images are unavailable on invoices and POS receipts. '
                'Fiscalisation and verification links still work. '
                f'Ask your administrator to run: {qr_install_command()}'
            )
        for settings in self:
            settings.totalvfd_qr_libraries_available = available
            settings.totalvfd_qr_libraries_message = message

    @api.depends('totalvfd_license_validation_configured')
    def _compute_totalvfd_module_license(self):
        license_model = self.env['total.vfd.license'].sudo()
        icp = self.env['ir.config_parameter'].sudo()
        for settings in self:
            lic = license_model._get_singleton()
            configured = settings.totalvfd_license_validation_configured

            if configured and not lic.license_word and lic.status != LICENSE_STATUS_ACTIVE:
                try:
                    lic.assign_license_word()
                except UserError:
                    pass

            settings.totalvfd_module_license_awaiting_key = (
                lic.status == LICENSE_STATUS_AWAITING_KEY
            )
            settings.totalvfd_module_license_status = lic.status
            settings.totalvfd_module_license_word = lic.license_word
            settings.totalvfd_module_license_database_uuid = license_model._get_database_uuid()
            if configured:
                try:
                    settings.totalvfd_module_license_vendor_message = (
                        license_model.get_vendor_message_for_customer()
                    )
                except UserError:
                    settings.totalvfd_module_license_vendor_message = False
            else:
                settings.totalvfd_module_license_vendor_message = False

            settings.totalvfd_module_license_step1_done = bool(
                configured and lic.license_word
            )
            settings.totalvfd_module_license_step2_done = (
                license_model.is_vendor_activation_code_saved()
            )
            settings.totalvfd_module_license_step3_done = (
                lic.status == LICENSE_STATUS_ACTIVE
            )
            settings.totalvfd_module_license_expiry = lic.expiry_date
            settings.totalvfd_module_license_days_remaining = lic.days_until_expiry
            settings.totalvfd_module_license_message = lic.status_message
            settings.totalvfd_module_license_warning = lic.warning_message or ''
            settings.totalvfd_module_license_active = lic.status == LICENSE_STATUS_ACTIVE
            settings.totalvfd_module_license_upgrade_reactivate = (
                license_model._needs_upgrade_reactivate()
            )
            settings.totalvfd_module_license_word_changed_notice = (
                icp.get_param('total_vfd.license.word_changed_notice') or ''
            )

    def action_totalvfd_test_license_server(self):
        self.ensure_one()
        icp = self.env['ir.config_parameter'].sudo()
        url = (self.totalvfd_license_validation_url or '').strip()
        key = (self.totalvfd_license_validation_api_key or '').strip()
        if not url or not key:
            raise UserError(
                'Enter the License Validation Server URL and API Key, then click Save '
                'before testing the connection.'
            )
        if not LicenseValidationClient.is_configured(self.env):
            raise UserError(
                'Replace placeholder URL/API key values, then click Save before testing.'
            )
        try:
            client = LicenseValidationClient.from_env(self.env)
            client.ping()
            msg = 'License validation server is reachable and the API key is valid.'
            msg_type = 'success'
        except LicenseValidationError as exc:
            if client.health():
                raise UserError(
                    f'{exc}\n\nThe server is reachable but authentication failed. '
                    'Check the API key matches validator_api_key in license_site config.php.'
                ) from exc
            raise UserError(
                f'{exc}\n\nCould not reach the server. Check the URL, HTTPS, and that '
                'license_site is running (ask your module vendor).'
            ) from exc

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'License server',
                'message': msg,
                'type': msg_type,
                'sticky': False,
            },
        }

    def action_totalvfd_activate_module_license(self):
        return self.env['total.vfd.license'].action_open_activate_wizard()

    def action_totalvfd_renew_module_license(self):
        return self.env['total.vfd.license'].action_open_renew_wizard()

    def action_totalvfd_show_vendor_message(self):
        return self.env['total.vfd.license'].action_show_vendor_message()

    def action_totalvfd_open_module_license(self):
        lic = self.env['total.vfd.license']._get_singleton()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Module License',
            'res_model': 'total.vfd.license',
            'view_mode': 'form',
            'res_id': lic.id,
            'target': 'current',
        }
