# -*- coding: utf-8 -*-

from odoo import fields, models


class PosConfig(models.Model):
    _inherit = 'pos.config'

    totalvfd_fiscalise_default = fields.Boolean(
        string='Fiscalise with Total VFD by Default',
        default=False,
        help='New POS orders will have fiscalisation enabled by default.',
    )
