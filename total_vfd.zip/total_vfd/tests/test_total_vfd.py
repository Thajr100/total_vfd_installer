# -*- coding: utf-8 -*-

from odoo import fields
from odoo.tests import tagged
from odoo.tests.common import TransactionCase

from odoo.addons.total_vfd.services.payload_builder import PayloadBuilder, TIN_PATTERN


@tagged('post_install', '-at_install')
class TestTotalVfd(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.company.write({
            'totalvfd_serial': '10TZ100614',
            'totalvfd_default_vat_group': 'A',
            'totalvfd_bearer_token': 'test-token',
            'totalvfd_active_business': 'test-business',
            'totalvfd_environment': 'sandbox',
        })
        cls.partner = cls.env['res.partner'].create({
            'name': 'Test Customer',
            'mobile': '0754332323',
            'vat': '123456789',
        })
        cls.product = cls.env['product.product'].create({
            'name': 'Test Product',
            'default_code': 'fgps201',
            'list_price': 2500.0,
            'taxes_id': [(5, 0, 0)],
        })

    def test_tin_validation(self):
        self.assertTrue(TIN_PATTERN.match('123456789'))
        self.assertFalse(TIN_PATTERN.match('12345'))
        self.assertFalse(TIN_PATTERN.match('1234567890'))

    def test_customer_tin_payload(self):
        builder = PayloadBuilder(self.env, self.company)
        customer = builder._build_customer_from_partner(self.partner)
        self.assertEqual(customer['idType'], 1)
        self.assertEqual(customer['idValue'], '123456789')

    def test_customer_without_tin(self):
        partner = self.env['res.partner'].create({'name': 'No TIN Customer'})
        builder = PayloadBuilder(self.env, self.company)
        customer = builder._build_customer_from_partner(partner)
        self.assertEqual(customer['idType'], 6)
        self.assertEqual(customer['idValue'], '')

    def test_invoice_payload_structure(self):
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'is_fiscalised': False,
            'invoice_line_ids': [(0, 0, {
                'product_id': self.product.id,
                'name': 'Test Product',
                'quantity': 1,
                'price_unit': 2500.0,
            })],
        })
        move.action_post()
        builder = PayloadBuilder(self.env, self.company)
        payload = builder.build_from_move(move)
        self.assertEqual(payload['serial'], '10TZ100614')
        self.assertEqual(len(payload['items']), 1)
        self.assertEqual(payload['items'][0]['id'], 'fgps201')
        self.assertEqual(payload['items'][0]['price'], 2500.0)
        self.assertEqual(payload['items'][0]['qty'], 1)
        self.assertEqual(payload['items'][0]['discount'], 0.0)
        self.assertEqual(payload['items'][0]['vatGroup'], 'A')
        self.assertEqual(payload['payments'][0]['type'], 'invoice')
        self.assertEqual(payload['payments'][0]['amount'], 2500.0)
        self.assertEqual(payload['customer']['name'], 'Test Customer')
        self.assertEqual(payload['customer']['idType'], 1)
        self.assertEqual(payload['customer']['idValue'], '123456789')

    def test_credit_note_not_fiscalisable(self):
        credit_note = self.env['account.move'].create({
            'move_type': 'out_refund',
            'partner_id': self.partner.id,
            'is_fiscalised': True,
            'invoice_line_ids': [(0, 0, {
                'product_id': self.product.id,
                'quantity': 1,
                'price_unit': 2500.0,
            })],
        })
        credit_note.action_post()
        builder = PayloadBuilder(self.env, self.company)
        with self.assertRaises(ValueError):
            builder.build_from_move(credit_note)
        self.assertFalse(credit_note.totalvfd_sent)

    def _create_percent_tax(self, name, amount):
        return self.env['account.tax'].create({
            'name': name,
            'amount_type': 'percent',
            'amount': amount,
            'type_tax_use': 'sale',
        })

    def test_vat_group_18_percent_maps_to_a(self):
        tax_18 = self._create_percent_tax('VAT 18%', 18.0)
        self.company.totalvfd_use_default_vat_group_all = False
        self.company.totalvfd_default_vat_group = 'B'
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, tax_18)
        self.assertEqual(group, 'A')

    def test_vat_group_zero_percent_maps_to_c(self):
        tax_0 = self._create_percent_tax('VAT 0%', 0.0)
        self.company.totalvfd_use_default_vat_group_all = False
        self.company.totalvfd_default_vat_group = 'B'
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, tax_0)
        self.assertEqual(group, 'C')

    def test_vat_group_other_rate_uses_default(self):
        tax_5 = self._create_percent_tax('VAT 5%', 5.0)
        self.company.totalvfd_use_default_vat_group_all = False
        self.company.totalvfd_default_vat_group = 'B'
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, tax_5)
        self.assertEqual(group, 'B')

    def test_vat_group_manual_from_product(self):
        self.company.totalvfd_vat_mapping_mode = 'manual'
        self.company.totalvfd_default_vat_group = 'A'
        self.product.product_tmpl_id.totalvfd_vat_group = 'B'
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, self.env['account.tax'])
        self.assertEqual(group, 'B')

    def test_vat_group_manual_from_tax(self):
        tax = self._create_percent_tax('Manual Tax', 18.0)
        tax.totalvfd_vat_group = 'C'
        self.company.totalvfd_vat_mapping_mode = 'manual'
        self.product.product_tmpl_id.totalvfd_vat_group = 'B'
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, tax)
        self.assertEqual(group, 'C')

    def test_vat_group_auto_mode_ignores_product_vat_group(self):
        self.company.totalvfd_vat_mapping_mode = 'auto'
        self.company.totalvfd_use_default_vat_group_all = False
        self.company.totalvfd_default_vat_group = 'B'
        self.product.product_tmpl_id.totalvfd_vat_group = 'C'
        tax_18 = self._create_percent_tax('VAT 18% manual ignore', 18.0)
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, tax_18)
        self.assertEqual(group, 'A')

    def test_vat_group_override_uses_default_for_all(self):
        tax_18 = self._create_percent_tax('VAT 18% override', 18.0)
        self.company.totalvfd_use_default_vat_group_all = True
        self.company.totalvfd_default_vat_group = 'B'
        builder = PayloadBuilder(self.env, self.company)
        group = builder._get_vat_group(self.product, tax_18)
        self.assertEqual(group, 'B')

    def test_payment_amount_excludes_line_discounts(self):
        builder = PayloadBuilder(self.env, self.company)
        items = [
            {'price': 2500.0, 'discount': 0.0},
            {'price': 5000.0, 'discount': 250.0},
        ]
        amount = builder._payment_amount_from_items(items)
        self.assertEqual(amount, 7250.0)

    def test_payment_type_invoice_lowercase(self):
        builder = PayloadBuilder(self.env, self.company)
        self.assertEqual(builder._format_payment_type('invoice'), 'invoice')
        self.assertEqual(builder._format_payment_type('Invoice'), 'invoice')
        payments = builder._build_payments_from_items([], 100.0, payment_type='Invoice')
        self.assertEqual(payments[0]['type'], 'invoice')

    def test_usd_invoice_converted_to_company_tzs(self):
        tzs = self.env['res.currency'].search([('name', '=', 'TZS')], limit=1)
        if not tzs:
            tzs = self.env['res.currency'].create({
                'name': 'TZS',
                'symbol': 'TSh',
                'rounding': 0.01,
            })
        usd = self.env.ref('base.USD')
        self.company.write({
            'currency_id': tzs.id,
            'totalvfd_convert_foreign_currency': True,
        })
        self.env['res.currency.rate'].create({
            'name': fields.Date.today(),
            'rate': 2500.0,
            'currency_id': usd.id,
            'company_id': self.company.id,
        })
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'currency_id': usd.id,
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': [(0, 0, {
                'product_id': self.product.id,
                'quantity': 1,
                'price_unit': 100.0,
            })],
        })
        move.action_post()
        builder = PayloadBuilder(self.env, self.company)
        payload = builder.build_from_move(move)
        self.assertEqual(payload['items'][0]['price'], 250000.0)
        self.assertEqual(payload['payments'][0]['amount'], 250000.0)

    def test_pos_payments_match_items_not_raw_payment_lines(self):
        """POS API payment must equal sum(items), not split pos.payment rows."""
        builder = PayloadBuilder(self.env, self.company)
        items = [{'price': 10000.0, 'discount': 500.0}]
        payments = builder._build_pos_payments(
            self.env['pos.order'].browse(),
            items,
            fields.Date.today(),
        )
        self.assertEqual(len(payments), 1)
        self.assertEqual(payments[0]['amount'], 9500.0)

    def test_pos_items_reconcile_to_order_total(self):
        builder = PayloadBuilder(self.env, self.company)
        order = self.env['pos.order'].new({'amount_total': 100.05})
        items = [{'price': 50.0, 'discount': 0.0}, {'price': 50.0, 'discount': 0.0}]
        reconciled = builder._reconcile_pos_items_to_order_total(
            items,
            order,
            self.env.company.currency_id,
            fields.Date.today(),
        )
        self.assertEqual(
            builder._payment_amount_from_items(reconciled),
            100.05,
        )

    def test_pos_fiscal_success_copies_to_linked_invoice(self):
        """POS fiscal receipt must appear on the linked customer invoice."""
        pos_order = self.env['pos.order'].new({
            'pos_reference': 'Order 0001-001-0001',
            'is_fiscalised': True,
            'fiscal_status': 'success',
            'totalvfd_sent': True,
            'totalvfd_rctvnum': 'RCTV-TEST-001',
            'totalvfd_verification_link': 'https://verify.example/1',
            'totalvfd_local_time': '2026-05-20 12:00:00',
        })
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'invoice_line_ids': [(0, 0, {
                'product_id': self.product.id,
                'quantity': 1,
                'price_unit': 2500.0,
            })],
        })
        move._total_vfd_apply_fiscal_from_pos_order(pos_order)
        self.assertEqual(move.fiscal_status, 'success')
        self.assertEqual(move.totalvfd_rctvnum, 'RCTV-TEST-001')
        self.assertTrue(move.is_fiscalised)

    def test_fiscalise_skipped_when_not_checked(self):
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'is_fiscalised': False,
            'invoice_line_ids': [(0, 0, {
                'product_id': self.product.id,
                'quantity': 1,
                'price_unit': 100.0,
            })],
        })
        move.action_post()
        self.assertFalse(move.totalvfd_sent)
        self.assertEqual(move.fiscal_status, 'pending')
