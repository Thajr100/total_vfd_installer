# -*- coding: utf-8 -*-

import sys
from pathlib import Path
from unittest.mock import patch

from odoo import fields
from odoo.exceptions import UserError
from odoo.tests import tagged
from odoo.tests.common import TransactionCase

from odoo.addons.total_vfd.services.license_constants import (
    LICENSE_DURATION_DAYS,
    LICENSE_STATUS_ACTIVE,
    LICENSE_STATUS_AWAITING_KEY,
)
from odoo.addons.total_vfd.services.license_service import LicenseService
from odoo.addons.total_vfd.services.license_validation_client import LicenseValidationClient

VENDOR_DIR = Path(__file__).resolve().parents[3] / 'license_vendor'
if str(VENDOR_DIR) not in sys.path:
    sys.path.insert(0, str(VENDOR_DIR))
from license_crypto import issue_license_for_customer_word  # noqa: E402


@tagged('post_install', '-at_install')
class TestTotalVfdLicense(TransactionCase):

    def setUp(self):
        super().setUp()
        self.icp = self.env['ir.config_parameter'].sudo()
        self.icp.set_param(
            'total_vfd.license_validation_url',
            'https://license.test.example',
        )
        self.icp.set_param('total_vfd.license_validation_api_key', 'test-api-key')
        self.License = self.env['total.vfd.license'].sudo()
        self.license = self.License._get_singleton()
        self.license.write({
            'status': LICENSE_STATUS_AWAITING_KEY,
            'license_word': False,
            'license_key_hash': False,
            'activation_date': False,
            'expiry_date': False,
            'integrity_seal': False,
            'grant_id': False,
        })
        self.icp.set_param('total_vfd.license.pending_verification_token', '')
        self.site_id = self.License._get_database_uuid()

    def _activate_api_response(self, base_word, bundle):
        today = fields.Date.context_today(self.License)
        expiry = fields.Date.add(today, days=LICENSE_DURATION_DAYS)
        return {
            'ok': True,
            'license': {
                'site_id': self.site_id,
                'base_word': base_word,
                'activation_phrase': f'{base_word}Tanzania',
                'license_key_hash': bundle['license_key_hash'],
                'status': LICENSE_STATUS_ACTIVE,
                'activation_date': today.isoformat(),
                'expiry_date': expiry.isoformat(),
                'integrity_seal': 'abc123seal',
                'vendor_activation_code_pending': '',
            },
        }

    def test_requires_validation_server_config(self):
        self.icp.set_param('total_vfd.license_validation_url', '')
        with self.assertRaises(UserError) as err:
            self.License.assign_license_word()
        self.assertIn('validation server', str(err.exception).lower())

    @patch.object(LicenseValidationClient, 'ping', return_value={'ok': True})
    def test_validation_client_ping(self, _mock_ping):
        client = LicenseValidationClient.from_env(self.env)
        self.assertTrue(client.ping().get('ok'))

    @patch.object(LicenseValidationClient, 'activate')
    @patch.object(LicenseValidationClient, 'assign_word')
    def test_upgrade_flag_cleared_on_activate(self, mock_assign, mock_activate):
        base_word = 'Mauzo'
        mock_assign.return_value = {
            'site_id': self.site_id,
            'base_word': base_word,
            'activation_phrase': 'MauzoTanzania',
            'status': LICENSE_STATUS_AWAITING_KEY,
        }
        self.icp.set_param('total_vfd.license.upgrade_reactivate', '1')
        self.license.assign_license_word()
        bundle = issue_license_for_customer_word(base_word)
        mock_activate.return_value = self._activate_api_response(base_word, bundle)
        self.License.activate_license(
            bundle['license_key'],
            verification_token=bundle['verification_token'],
        )
        self.assertIn(
            self.icp.get_param('total_vfd.license.upgrade_reactivate'),
            ('0', False),
        )

    @patch.object(LicenseValidationClient, 'assign_word')
    @patch.object(LicenseValidationClient, 'activate')
    def test_combined_activation_wizard_flow(self, mock_activate, mock_assign):
        base_word = 'Mauzo'
        mock_assign.return_value = {
            'site_id': self.site_id,
            'base_word': base_word,
            'activation_phrase': 'MauzoTanzania',
            'status': LICENSE_STATUS_AWAITING_KEY,
        }
        self.license.assign_license_word()
        bundle = issue_license_for_customer_word(base_word)
        mock_activate.return_value = self._activate_api_response(base_word, bundle)

        wizard = self.env['total.vfd.license.activate.wizard'].create({
            'vendor_activation_code': bundle['verification_token'],
            'license_key': bundle['license_key'],
        })
        wizard.action_activate()
        self.assertEqual(wizard.state, 'success')
        self.assertEqual(self.license.status, LICENSE_STATUS_ACTIVE)
        mock_activate.assert_called_once()

    def test_auto_verification_phrase(self):
        self.assertEqual(
            LicenseService.verification_word('Mauzo'),
            'MauzoTanzania',
        )

    def test_decode_verification_token_multiline(self):
        bundle = issue_license_for_customer_word('Mauzo')
        broken = bundle['verification_token'][:40] + '\n' + bundle['verification_token'][40:]
        decoded = LicenseService.decode_verification_token(broken)
        self.assertTrue(decoded.startswith('$pbkdf2-sha256$'))

    @patch.object(LicenseValidationClient, 'assign_word')
    def test_vendor_message_includes_database_id(self, mock_assign):
        base_word = 'Bidhaa'
        mock_assign.return_value = {
            'site_id': self.site_id,
            'base_word': base_word,
            'activation_phrase': 'BidhaaTanzania',
            'status': LICENSE_STATUS_AWAITING_KEY,
        }
        self.license.assign_license_word()
        msg = self.License.get_vendor_message_for_customer()
        self.assertIn(base_word, msg)
        self.assertIn('Site ID', msg)
