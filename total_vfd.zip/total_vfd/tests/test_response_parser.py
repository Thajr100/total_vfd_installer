# -*- coding: utf-8 -*-

from odoo.tests import tagged
from odoo.tests.common import TransactionCase

from odoo.addons.total_vfd.services.response_parser import TotalVfdResponseParser


DUPLICATE_409_BODY = {
    'msg': 'Reference number already used.',
    'data': {
        'rctvnum': 'C4A9EB604968',
        'localTime': '16:41:38',
        'localDate': '2026-05-18',
        'verificationLink': 'https://virtual.tra.go.tz/efdmsrctverify/C4A9EB604968_164138',
        'rctnum': 604968,
        'gc': 604968,
        'zNumber': '20260518',
    },
}

SUCCESS_BODY = {
    'rctvnum': 'C4A9EB604968',
    'localTime': '16:41:38',
    'localDate': '2026-05-18',
    'verificationLink': 'https://virtual.tra.go.tz/efdmsrctverify/C4A9EB604968_164138',
}


@tagged('post_install', '-at_install')
class TestTotalVfdResponseParser(TransactionCase):

    def test_extract_success_body(self):
        payload = TotalVfdResponseParser.extract_fiscal_payload(SUCCESS_BODY)
        self.assertEqual(payload['rctvnum'], 'C4A9EB604968')

    def test_extract_duplicate_nested_data(self):
        payload = TotalVfdResponseParser.extract_fiscal_payload(DUPLICATE_409_BODY)
        self.assertEqual(payload['rctvnum'], 'C4A9EB604968')

    def test_parse_fiscal_fields(self):
        fields = TotalVfdResponseParser.parse_fiscal_fields(SUCCESS_BODY)
        self.assertEqual(fields['totalvfd_rctvnum'], 'C4A9EB604968')
        self.assertEqual(fields['totalvfd_local_time'], '2026-05-18 16:41:38')
        self.assertIn('efdmsrctverify', fields['totalvfd_verification_link'])

    def test_extract_error_message_from_msg(self):
        message = TotalVfdResponseParser.extract_error_message(DUPLICATE_409_BODY, 409)
        self.assertEqual(message, 'Reference number already used.')
