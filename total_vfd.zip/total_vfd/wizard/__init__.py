# -*- coding: utf-8 -*-

from . import total_vfd_license_activate_wizard
from . import total_vfd_retry_wizard
from . import total_vfd_setup_wizard
