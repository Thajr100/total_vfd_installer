# -*- coding: utf-8 -*-

from odoo import fields, models


class TotalVfdRetryWizard(models.TransientModel):
    _name = 'total.vfd.retry.wizard'
    _description = 'Retry Total VFD Fiscalisation'

    res_model = fields.Char(string='Model', required=True)
    res_id = fields.Integer(string='Record ID', required=True)
    message = fields.Text(string='Message', readonly=True)

    def action_retry_now(self):
        self.ensure_one()
        record = self.env[self.res_model].browse(self.res_id).exists()
        if not record:
            self.message = 'Record not found.'
            return self._reopen_wizard()
        if not record.is_fiscalised:
            self.message = 'Fiscalisation is not enabled on this record.'
            return self._reopen_wizard()
        record.action_retry_total_vfd_fiscalisation()
        self.message = 'Fiscalisation retry has been triggered.'
        return {'type': 'ir.actions.act_window_close'}

    def _reopen_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }
