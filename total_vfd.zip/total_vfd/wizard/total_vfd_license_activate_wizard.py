# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import UserError

from odoo.addons.total_vfd.services.license_service import LicenseService, LicenseServiceError
from odoo.addons.total_vfd.services.license_validation_client import LicenseValidationError


class TotalVfdLicenseActivateWizard(models.TransientModel):
    _name = 'total.vfd.license.activate.wizard'
    _description = 'Activate or Renew Total VFD Module License'

    renew = fields.Boolean(string='Renewal', default=False)
    state = fields.Selection(
        selection=[('input', 'Input'), ('success', 'Success')],
        default='input',
    )
    license_word_base = fields.Char(
        string='Your License Word (tell vendor)',
        readonly=True,
    )
    vendor_activation_code = fields.Text(
        string='Vendor Activation Code',
        help='Paste the long code from your vendor email (one-time registration).',
    )
    license_key = fields.Char(
        string='License Key',
        help='Format: XXXXXX-XXXXXX-XXXXXX-XXXXXX',
    )
    vendor_code_already_saved = fields.Boolean(
        string='Vendor Code Saved',
        compute='_compute_vendor_code_already_saved',
    )
    result_message = fields.Html(readonly=True)
    result_expiry = fields.Date(readonly=True)
    result_days_remaining = fields.Integer(readonly=True)

    @api.depends()
    def _compute_vendor_code_already_saved(self):
        icp = self.env['ir.config_parameter'].sudo()
        pending = icp.get_param('total_vfd.license.pending_verification_token') or ''
        for wizard in self:
            wizard.vendor_code_already_saved = bool(pending.strip())

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if not self.env['total.vfd.license']._is_validation_server_configured():
            return res
        lic = self.env['total.vfd.license'].sudo()._get_singleton()
        if not lic.license_word and not res.get('renew'):
            try:
                lic.assign_license_word()
            except UserError:
                pass
        if lic.license_word:
            res.setdefault('license_word_base', lic.license_word)
        return res

    def _get_vendor_token(self):
        self.ensure_one()
        token = (self.vendor_activation_code or '').strip()
        if not token:
            token = self.env['ir.config_parameter'].sudo().get_param(
                'total_vfd.license.pending_verification_token',
            ) or ''
        return LicenseService.normalize_verification_token(token)

    def action_activate(self):
        self.ensure_one()
        if not self.license_key or not str(self.license_key).strip():
            raise UserError('License Key is required (format: XXXXXX-XXXXXX-XXXXXX-XXXXXX).')

        token = self._get_vendor_token()
        if not self.renew and not token:
            raise UserError(
                'Paste your Vendor Activation Code from the vendor email, '
                'or register it first under Settings → Total VFD.'
            )

        lic = self.env['total.vfd.license'].sudo()._get_singleton()
        if not lic.license_word:
            lic.assign_license_word()

        if token and not self.renew:
            self.env['total.vfd.license'].action_register_vendor_token(token)

        try:
            license_record = self.env['total.vfd.license'].activate_license(
                self.license_key,
                verification_token=token or None,
                renew=self.renew,
            )
        except (UserError, LicenseServiceError, LicenseValidationError) as exc:
            raise UserError(str(exc)) from exc

        self.write({
            'state': 'success',
            'result_expiry': license_record.expiry_date,
            'result_days_remaining': license_record.days_until_expiry,
            'result_message': (
                f'<p class="text-success mb-2"><strong>License '
                f'{"renewed" if self.renew else "activated"} successfully.</strong></p>'
                f'<p>Valid until <strong>{license_record.expiry_date}</strong> '
                f'({license_record.days_until_expiry} days remaining).</p>'
            ),
        })
        return {
            'type': 'ir.actions.act_window',
            'name': 'License Active',
            'res_model': self._name,
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'new',
        }

    def action_configure_total_vfd(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Total VFD Settings',
            'res_model': 'res.config.settings',
            'view_mode': 'form',
            'target': 'inline',
            'context': {
                'module': 'total_vfd',
                'bin_size': True,
            },
        }

    def action_close(self):
        return {'type': 'ir.actions.act_window_close'}
