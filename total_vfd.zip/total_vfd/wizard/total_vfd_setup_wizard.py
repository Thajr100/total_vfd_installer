# -*- coding: utf-8 -*-

from odoo import fields, models


class TotalVfdSetupWizard(models.TransientModel):
    _name = 'total.vfd.setup.wizard'
    _description = 'Total VFD Quick Setup'

    message = fields.Html(
        readonly=True,
        default=lambda self: self._default_message(),
    )

    @staticmethod
    def _default_message():
        return """
        <p><strong>Welcome to Total VFD Fiscalisation</strong></p>
        <ol>
            <li><strong>License validation server</strong> — open
                <strong>Settings → Total VFD</strong>, enter the server URL and API key
                (from your integrator), click <strong>Save</strong>, then
                <strong>Test connection</strong>.</li>
            <li><strong>Module license</strong> — copy your license word for your vendor;
                when they email you, use <strong>Activate License</strong> (code + key).</li>
            <li><strong>Total VFD API</strong> — Bearer token, active business, serial, environment.</li>
            <li><strong>Test</strong> — post a customer invoice with
                <strong>Fiscalise with Total VFD</strong> enabled.</li>
        </ol>
        <p>Upgrading from an older version? Open <strong>Settings → Total VFD</strong>
        and activate your license again with your vendor code and key, or ask your vendor.</p>
        <p>Need help? <strong>Accounting → Configuration → Total VFD → Fiscal Logs</strong>
        after your first test.</p>
        """

    def action_open_settings(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Total VFD Settings',
            'res_model': 'res.config.settings',
            'view_mode': 'form',
            'target': 'inline',
            'context': {
                'module': 'total_vfd',
                'bin_size': True,
            },
        }

    def action_mark_setup_done(self):
        self.env['ir.config_parameter'].sudo().set_param('total_vfd.setup_complete', '1')
        return {'type': 'ir.actions.act_window_close'}
