# -*- coding: utf-8 -*-
{
    'name': 'Total VFD Fiscalisation',
    'version': '18.0.1.9.11',
    'category': 'Accounting/Localizations',
    'summary': 'Integrate customer invoices, sales, and POS with Total VFD API',
    'description': """
Total VFD Fiscalisation
=======================
Fiscalise customer invoices (out_invoice), sales invoices, and POS orders
through the Total VFD fiscalisation API with queue-based retry support.
Credit notes are not fiscalised.
    """,
    'author': 'Total VFD Integration',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'web',
        'account',
        'product',
        'sale',
        'point_of_sale',
        'base_setup',
    ],
    'pre_init_hook': 'pre_init_hook',
    'post_init_hook': 'post_init_hook',
    'data': [
        'security/total_vfd_security.xml',
        'security/ir.model.access.csv',
        'data/total_vfd_license_sequence.xml',
        'data/total_vfd_license_data.xml',
        'data/ir_cron_data.xml',
        'data/ir_cron_license.xml',
        'views/total_vfd_license_views.xml',
        'views/total_vfd_license_wizard_views.xml',
        'views/res_config_settings_views.xml',
        'views/res_company_views.xml',
        'views/account_move_views.xml',
        'views/pos_config_views.xml',
        'views/pos_order_views.xml',
        'views/product_template_views.xml',
        'views/total_vfd_log_views.xml',
        'views/total_vfd_queue_views.xml',
        'views/total_vfd_menus.xml',
        'views/total_vfd_setup_wizard_views.xml',
        'report/account_move_report.xml',
    ],
    'external_dependencies': {
        'python': ['requests'],
    },
    'assets': {
        'point_of_sale._assets_pos': [
            'total_vfd/static/src/js/pos_store.js',
            'total_vfd/static/src/js/pos_order.js',
            'total_vfd/static/src/js/control_buttons.js',
            'total_vfd/static/src/xml/pos_control_buttons.xml',
            'total_vfd/static/src/xml/pos_receipt.xml',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
