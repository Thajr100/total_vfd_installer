# -*- coding: utf-8 -*-

import logging

import requests

_logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 30


class LicenseValidationError(Exception):
    """License validation server returned an error."""

    def __init__(self, message, http_status=None):
        super().__init__(message)
        self.http_status = http_status


class LicenseValidationClient:
    """HTTP client for vendor license validation API (license_site)."""

    def __init__(self, base_url, api_key):
        self.base_url = (base_url or '').strip().rstrip('/')
        self.api_key = (api_key or '').strip()
        if not self.base_url:
            raise LicenseValidationError('License validation server URL is not configured.')
        if not self.api_key:
            raise LicenseValidationError('License validation API key is not configured.')

    @classmethod
    def from_env(cls, env):
        icp = env['ir.config_parameter'].sudo()
        return cls(
            icp.get_param('total_vfd.license_validation_url'),
            icp.get_param('total_vfd.license_validation_api_key'),
        )

    @classmethod
    def is_configured(cls, env):
        icp = env['ir.config_parameter'].sudo()
        url = (icp.get_param('total_vfd.license_validation_url') or '').strip()
        key = (icp.get_param('total_vfd.license_validation_api_key') or '').strip()
        placeholders = (
            '',
            'change-me-validator-api-key',
            'https://licenses.example.com',
        )
        if not url or not key or url in placeholders or key in placeholders:
            return False
        return True

    def api_prefix(self):
        if self.base_url.endswith('/api/v1'):
            return self.base_url
        return f'{self.base_url}/api/v1'

    def _headers(self):
        return {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }

    def _post(self, path, payload):
        path = path if path.startswith('/') else f'/{path}'
        url = f'{self.api_prefix()}{path}'
        try:
            response = requests.post(
                url,
                headers=self._headers(),
                json=payload,
                timeout=DEFAULT_TIMEOUT,
            )
        except requests.Timeout as exc:
            raise LicenseValidationError(
                'License validation server timed out. Check the server URL and network.'
            ) from exc
        except requests.ConnectionError as exc:
            raise LicenseValidationError(
                'Cannot reach the license validation server. Check the URL and HTTPS certificate.'
            ) from exc
        except requests.RequestException as exc:
            raise LicenseValidationError(str(exc)) from exc

        try:
            data = response.json()
        except ValueError:
            data = {'ok': False, 'error': response.text or response.reason}

        if response.status_code == 401:
            raise LicenseValidationError(
                'License validation API key was rejected (401). Check Settings → Total VFD.',
                http_status=401,
            )
        if response.status_code == 503:
            raise LicenseValidationError(
                data.get('error') or 'License validation API is disabled on the server.',
                http_status=503,
            )
        if not isinstance(data, dict):
            raise LicenseValidationError('Invalid response from license validation server.')

        if response.status_code >= 400 or data.get('ok') is False and 'valid' not in data:
            message = data.get('error') or data.get('message') or f'HTTP {response.status_code}'
            raise LicenseValidationError(message, http_status=response.status_code)

        return data

    def assign_word(self, site_id):
        return self._post('/license/assign-word', {'site_id': site_id})

    def activate(self, site_id, license_key, license_payload, vendor_code=None):
        body = {
            'site_id': site_id,
            'license_key': license_key,
            'license': license_payload,
        }
        if vendor_code:
            body['x'] = vendor_code
        return self._post('/license/activate', body)

    def check(self, license_payload):
        data = self._post('/license/check', license_payload)
        if data.get('ok') is not True:
            raise LicenseValidationError(
                data.get('error') or 'License check failed.',
                http_status=403,
            )
        return data

    def ping(self):
        """Authenticated ping — verifies URL and API key."""
        return self._post('/ping', {})

    def health(self):
        """Unauthenticated health (reachability only)."""
        url = f'{self.base_url}/api/health'
        if self.base_url.endswith('/api/v1'):
            url = self.base_url.replace('/api/v1', '/api/health')
        try:
            response = requests.get(url, timeout=10)
            return response.status_code == 200
        except requests.RequestException:
            return False
