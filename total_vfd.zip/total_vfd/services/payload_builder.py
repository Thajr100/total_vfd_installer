# -*- coding: utf-8 -*-

import logging
import re

from odoo import fields

_logger = logging.getLogger(__name__)

TIN_PATTERN = re.compile(r'^\d{9}$')
ID_TYPE_TIN = 1
ID_TYPE_NONE = 6
VAT_RATE_STANDARD = 18.0
VAT_GROUP_STANDARD = 'A'
VAT_GROUP_ZERO = 'C'
RATE_TOLERANCE = 0.001


class PayloadBuilder:
    """
    Build Total VFD receipt payloads from Odoo records.

    API semantics (invoice and POS use the same rules):
    - item ``price``: tax-inclusive line total for full ``qty``, before ``discount``
    - item ``discount``: monetary discount on that line
    - payment ``amount``: sum of (price - discount) for all items
    - payment ``type``: lowercase label (e.g. ``invoice``, ``cash``)
    """

    def __init__(self, env, company):
        self.env = env
        self.company = company
        self._fiscal_currency = company.currency_id

    def build_from_move(self, move):
        """Build payload from account.move (customer invoice only)."""
        self._ensure_move_eligible(move)
        conversion_date = move.invoice_date or move.date
        items = self._build_move_items(move, conversion_date)
        return {
            'referenceNumber': self._move_reference(move),
            'serial': self.company.totalvfd_serial,
            'items': items,
            'customer': self._build_customer_from_partner(move.partner_id),
            'payments': self._build_payments_from_items(
                items,
                move.amount_total,
                payment_type='invoice',
                from_currency=move.currency_id,
                conversion_date=conversion_date,
            ),
        }

    def build_from_pos_order(self, order):
        """Build payload from pos.order."""
        conversion_date = order.date_order.date() if order.date_order else fields.Date.context_today(self.env)
        from_currency = order.currency_id
        items = self._build_pos_items(order, conversion_date)
        items = self._reconcile_pos_items_to_order_total(
            items, order, from_currency, conversion_date,
        )
        return {
            'referenceNumber': order.pos_reference or order.name or str(order.id),
            'serial': self.company.totalvfd_serial,
            'items': items,
            'customer': self._build_customer_from_pos_order(order),
            'payments': self._build_pos_payments(order, items, conversion_date),
        }

    def _ensure_move_eligible(self, move):
        if move.state != 'posted':
            raise ValueError('Invoice must be posted before fiscalisation.')
        if move.move_type != 'out_invoice':
            raise ValueError('Only customer invoices (out_invoice) can be fiscalised.')
        if self.company.totalvfd_convert_foreign_currency:
            fiscal = self._fiscal_currency
            if fiscal.name != 'TZS':
                raise ValueError(
                    'Total VFD requires amounts in TZS. Set the company currency to TZS '
                    '(Settings → Companies), or disable foreign-currency conversion.'
                )

    def _convert_to_fiscal_currency(self, amount, from_currency, conversion_date):
        """Convert document currency amounts to company currency (expected TZS) for the API."""
        if amount in (None, False):
            return 0.0
        amount = abs(float(amount))
        if not self.company.totalvfd_convert_foreign_currency:
            return round(amount, 2)
        fiscal = self._fiscal_currency
        if not from_currency or from_currency == fiscal:
            return round(amount, 2)
        if not conversion_date:
            conversion_date = fields.Date.context_today(self.env)
        converted = from_currency._convert(
            amount,
            fiscal,
            self.company,
            conversion_date,
        )
        return round(converted, 2)

    @staticmethod
    def _move_reference(move):
        return move.name or move.ref or str(move.id)

    def _get_fiscalisable_move_lines(self, move):
        """Return product lines for customer invoices."""
        lines = move.invoice_line_ids.filtered(
            lambda line: line.display_type not in ('line_section', 'line_note')
        )
        if not lines:
            lines = move.line_ids.filtered(lambda line: line.display_type == 'product')
        return lines.filtered(
            lambda line: line.product_id or line.display_type == 'product'
        )

    def _build_move_items(self, move, conversion_date):
        items = []
        from_currency = move.currency_id
        for line in self._get_fiscalisable_move_lines(move):
            item = self._build_item_from_move_line(line, from_currency, conversion_date)
            if item['price'] or item['qty']:
                items.append(item)
        if not items:
            raise ValueError('No fiscalisable lines found on the document.')
        return items

    def _build_pos_items(self, order, conversion_date):
        items = []
        from_currency = order.currency_id
        for line in order.lines:
            if line.qty == 0:
                continue
            items.append(self._build_item_from_pos_line(line, from_currency, conversion_date))
        if not items:
            raise ValueError('No fiscalisable lines found on the POS order.')
        return items

    def _build_item_from_move_line(self, line, from_currency, conversion_date):
        product = line.product_id
        discount = self._line_discount_amount(line)
        line_price = self._invoice_line_price_tax_inclusive_before_discount(line, discount)
        return {
            'id': self._product_reference(product),
            'name': line.name or (product.display_name if product else 'Line'),
            'price': self._convert_to_fiscal_currency(line_price, from_currency, conversion_date),
            'qty': abs(line.quantity),
            'vatGroup': self._get_vat_group(product, line.tax_ids),
            'discount': self._convert_to_fiscal_currency(discount, from_currency, conversion_date),
        }

    @staticmethod
    def _line_discount_amount(line):
        if hasattr(line, 'discount_amount') and line.discount_amount:
            return abs(line.discount_amount)
        if line.discount:
            return abs(line.price_unit) * abs(line.quantity) * line.discount / 100.0
        return 0.0

    def _invoice_line_price_tax_inclusive_before_discount(self, line, discount):
        """
        Line total for all qty: tax-inclusive, before discount is applied.
        """
        net_tax_incl = self._invoice_line_total_tax_inclusive(line)
        return round(net_tax_incl + discount, 2)

    def _invoice_line_total_tax_inclusive(self, line):
        """Tax-inclusive line total after discount."""
        if getattr(line, 'price_total', None):
            return abs(line.price_total)
        quantity = abs(line.quantity) or 1.0
        taxes = line.tax_ids
        if taxes:
            currency = line.currency_id or line.move_id.currency_id
            totals = taxes.compute_all(
                line.price_unit,
                currency=currency,
                quantity=quantity,
                product=line.product_id,
                partner=line.move_id.partner_id,
                is_refund=line.move_id.move_type in ('out_refund', 'in_refund'),
            )
            return abs(totals['total_included'])
        return abs(line.price_subtotal)

    def _build_item_from_pos_line(self, line, from_currency, conversion_date):
        product = line.product_id
        discount = self._pos_line_discount_amount(line)
        line_price = self._pos_line_price_tax_inclusive_before_discount(line, discount)
        return {
            'id': self._product_reference(product),
            'name': line.full_product_name or product.display_name,
            'price': self._convert_to_fiscal_currency(line_price, from_currency, conversion_date),
            'qty': abs(line.qty),
            'vatGroup': self._get_vat_group(product, line.tax_ids),
            'discount': self._convert_to_fiscal_currency(discount, from_currency, conversion_date),
        }

    @staticmethod
    def _pos_line_discount_amount(line):
        if line.discount:
            return abs(line.price_unit) * abs(line.qty) * line.discount / 100.0
        return 0.0

    def _pos_line_price_tax_inclusive_before_discount(self, line, discount):
        """POS line total: tax-inclusive for full qty, before discount."""
        net_tax_incl = self._pos_line_total_tax_inclusive(line)
        return round(net_tax_incl + discount, 2)

    def _pos_line_total_tax_inclusive(self, line):
        if hasattr(line, 'price_subtotal_incl') and line.price_subtotal_incl:
            return abs(line.price_subtotal_incl)
        taxes = line.tax_ids
        if taxes:
            totals = taxes.compute_all(
                line.price_unit,
                currency=line.order_id.currency_id,
                quantity=abs(line.qty),
                product=line.product_id,
                partner=line.order_id.partner_id,
            )
            return abs(totals['total_included'])
        return abs(line.price_subtotal)

    def _product_reference(self, product):
        if product and product.default_code:
            return product.default_code
        return str(product.id) if product else '0'

    def _get_vat_group(self, product, taxes):
        default = self.company.totalvfd_default_vat_group or 'A'
        mode = self.company.totalvfd_vat_mapping_mode or 'auto'
        if mode == 'manual':
            return self._get_vat_group_manual(product, taxes, default)
        if self.company.totalvfd_use_default_vat_group_all:
            return default
        return self._get_vat_group_from_tax_rates(taxes, default)

    def _get_vat_group_manual(self, product, taxes, default):
        """Manual mode: tax VAT group, then product, then company default."""
        for tax in taxes:
            if tax.totalvfd_vat_group:
                return tax.totalvfd_vat_group
        if product:
            vat_group = product.totalvfd_vat_group or product.product_tmpl_id.totalvfd_vat_group
            if vat_group:
                return vat_group
        return default

    def _iter_percent_tax_rates(self, taxes):
        """Yield percent rates from taxes, including children of tax groups."""
        for tax in taxes:
            if tax.amount_type == 'percent':
                yield tax.amount
            elif tax.amount_type == 'group':
                yield from self._iter_percent_tax_rates(tax.children_tax_ids)

    def _get_vat_group_from_tax_rates(self, taxes, default):
        """Map 18% tax to A, 0% tax to C, any other rate to the configured default."""
        rates = sorted(self._iter_percent_tax_rates(taxes), reverse=True)
        if not rates:
            return default
        for rate in rates:
            if abs(rate - VAT_RATE_STANDARD) < RATE_TOLERANCE:
                return VAT_GROUP_STANDARD
            if abs(rate) < RATE_TOLERANCE:
                return VAT_GROUP_ZERO
        return default

    def _build_customer_from_pos_order(self, order):
        partner = self._resolve_pos_customer_partner(order)
        return self._build_customer_from_partner(partner)

    def _resolve_pos_customer_partner(self, order):
        """Use the selected POS customer, not a stale or generic walk-in partner."""
        partner = order.partner_id
        if partner and not self._is_generic_pos_partner(partner):
            return partner.commercial_partner_id or partner
        invoice_partner = order.account_move.partner_id if order.account_move else False
        if invoice_partner and not self._is_generic_pos_partner(invoice_partner):
            return invoice_partner.commercial_partner_id or invoice_partner
        return partner or self.env['res.partner']

    @staticmethod
    def _is_generic_pos_partner(partner):
        if not partner:
            return True
        name = (partner.name or '').strip().lower()
        return name in {
            'walk-in customer',
            'walk-in',
            'public customer',
            'consumer',
            'anonymous customer',
        }

    def _build_customer_from_partner(self, partner):
        partner = partner or self.env['res.partner']
        if partner and not partner.name and partner.commercial_partner_id:
            partner = partner.commercial_partner_id
        name = (partner.display_name or partner.name or '').strip() or 'Walk-in Customer'
        id_type, id_value = self._resolve_tin(partner)
        mobile = (partner.mobile or partner.phone or '').strip()
        return {
            'name': name,
            'mobile': mobile,
            'idType': id_type,
            'idValue': id_value,
        }

    def _resolve_tin(self, partner):
        tin = (partner.vat or '').strip()
        tin_digits = re.sub(r'\D', '', tin)
        if tin_digits and TIN_PATTERN.match(tin_digits):
            return ID_TYPE_TIN, tin_digits
        if tin_digits and not TIN_PATTERN.match(tin_digits):
            _logger.warning('Invalid TIN for partner %s: %s', partner.id, tin)
        return ID_TYPE_NONE, ''

    @staticmethod
    def _format_payment_type(payment_type):
        """Total VFD expects payment type with a leading lowercase letter (e.g. invoice, cash)."""
        text = (payment_type or 'invoice').strip()
        if not text:
            return 'invoice'
        return text[0].lower() + text[1:]

    @staticmethod
    def _payment_amount_from_items(items):
        """Total payable: sum of line prices minus all line discounts."""
        if not items:
            return 0.0
        return round(
            sum(item['price'] - item['discount'] for item in items),
            2,
        )

    def _build_payments_from_items(
        self,
        items,
        document_total,
        payment_type='invoice',
        from_currency=None,
        conversion_date=None,
    ):
        amount = self._payment_amount_from_items(items)
        if not amount and document_total:
            amount = self._convert_to_fiscal_currency(
                document_total, from_currency, conversion_date,
            )
        return [{
            'type': self._format_payment_type(payment_type),
            'amount': amount,
        }]

    def _reconcile_pos_items_to_order_total(self, items, order, from_currency, conversion_date):
        """
        Total VFD requires sum(item price - discount) == payment amount.
        POS cash rounding / global discounts can make lines and amount_total differ slightly.
        """
        if not items:
            return items
        items_total = self._payment_amount_from_items(items)
        order_total = self._convert_to_fiscal_currency(
            order.amount_total, from_currency, conversion_date,
        )
        diff = round(order_total - items_total, 2)
        if abs(diff) >= 0.01:
            _logger.info(
                'POS order %s: adjusting last line price by %s so items (%.2f) match order total (%.2f)',
                order.id,
                diff,
                items_total,
                order_total,
            )
            items[-1]['price'] = round(items[-1]['price'] + diff, 2)
        return items

    def _build_pos_payments(self, order, items, conversion_date):
        """
        Payment amount must match sum of item prices minus discounts (same as invoices).
        Do not use pos.payment amounts directly — they can include rounding or tips.
        """
        amount = self._payment_amount_from_items(items)
        if not amount:
            amount = self._convert_to_fiscal_currency(
                order.amount_total,
                order.currency_id,
                conversion_date,
            )
        payment_type = 'cash'
        if order.payment_ids:
            method = order.payment_ids[0].payment_method_id
            if method and method.name:
                payment_type = method.name
        return [{
            'type': self._format_payment_type(payment_type),
            'amount': amount,
        }]
