# -*- coding: utf-8 -*-

import importlib.util
import sys

REQUIRED_PACKAGES = {
    'requests': 'requests',
}

OPTIONAL_QR_PACKAGES = {
    'qrcode': 'qrcode',
    'PIL': 'Pillow',
}


def _missing_from(packages):
    missing = []
    for module_name, pip_name in packages.items():
        if importlib.util.find_spec(module_name) is None:
            missing.append(pip_name)
    return sorted(set(missing))


def missing_required_packages():
    return _missing_from(REQUIRED_PACKAGES)


def missing_optional_qr_packages():
    return _missing_from(OPTIONAL_QR_PACKAGES)


def qr_libraries_available():
    return not missing_optional_qr_packages()


def pip_install_command(packages):
    return f'{sys.executable} -m pip install {" ".join(packages)}'


def qr_install_command():
    missing = missing_optional_qr_packages()
    return pip_install_command(missing or ['qrcode', 'Pillow'])
