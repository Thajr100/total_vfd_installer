# -*- coding: utf-8 -*-

import base64
import logging
from io import BytesIO

_logger = logging.getLogger(__name__)


class QrGenerator:
    """Generate QR code images from verification URLs."""

    @staticmethod
    def generate_png(verification_link, box_size=6, border=2):
        """Return raw PNG bytes for Odoo Binary fields (invoice PDF + form image)."""
        if not verification_link:
            return False
        try:
            import qrcode
        except ImportError as exc:
            _logger.error('qrcode library is not installed: %s', exc)
            return False

        try:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_M,
                box_size=box_size,
                border=border,
            )
            qr.add_data(verification_link)
            qr.make(fit=True)
            image = qr.make_image(fill_color='black', back_color='white')
            buffer = BytesIO()
            image.save(buffer, format='PNG')
            return buffer.getvalue()
        except Exception as exc:
            _logger.exception('Failed to generate QR code: %s', exc)
            return False

    @staticmethod
    def generate_for_binary_field(verification_link, box_size=6, border=2):
        """PNG as base64 bytes for Odoo fields.Binary (attachment-safe)."""
        png = QrGenerator.generate_png(verification_link, box_size, border)
        if not png:
            return False
        return base64.b64encode(png)

    @staticmethod
    def generate_base64(verification_link, box_size=6, border=2):
        """Base64-encoded PNG bytes (e.g. POS receipt template)."""
        return QrGenerator.generate_for_binary_field(verification_link, box_size, border)
