# -*- coding: utf-8 -*-

from odoo.tools import sql


def migrate(cr, version):
    if not sql.column_exists(cr, 'res_company', 'totalvfd_convert_foreign_currency'):
        sql.create_column(cr, 'res_company', 'totalvfd_convert_foreign_currency', 'boolean')
        cr.execute(
            """
            UPDATE res_company
            SET totalvfd_convert_foreign_currency = TRUE
            WHERE totalvfd_convert_foreign_currency IS NULL
            """
        )
