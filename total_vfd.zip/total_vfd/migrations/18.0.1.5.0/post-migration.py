# -*- coding: utf-8 -*-

from odoo import SUPERUSER_ID, api


def _validation_configured(icp):
    url = (icp.get_param('total_vfd.license_validation_url') or '').strip()
    key = (icp.get_param('total_vfd.license_validation_api_key') or '').strip()
    placeholders = ('', 'change-me-validator-api-key', 'https://licenses.example.com')
    return bool(url and key and url not in placeholders and key not in placeholders)


def migrate(cr, version):
    """Flag active local licenses that must re-activate via license_site after upgrade."""
    env = api.Environment(cr, SUPERUSER_ID, {})
    icp = env['ir.config_parameter'].sudo()
    lic = env['total.vfd.license'].search([], limit=1)
    if lic and lic.status == 'active' and lic.license_key_hash:
        icp.set_param('total_vfd.license.upgrade_reactivate', '1')
    if not _validation_configured(icp):
        icp.set_param('total_vfd.license.validation_was_configured', '0')
