# -*- coding: utf-8 -*-
"""Ensure new company columns exist after manual zip deploy without full upgrade."""


def migrate(cr, version):
    cr.execute(
        """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = 'res_company'
          AND column_name = 'totalvfd_convert_foreign_currency'
        """
    )
    if not cr.fetchone():
        cr.execute(
            """
            ALTER TABLE res_company
            ADD COLUMN totalvfd_convert_foreign_currency boolean DEFAULT true
            """
        )
