/** @odoo-module **/

import { ControlButtons } from "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";
import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";

patch(ControlButtons.prototype, {
    clickTotalVfdFiscalise() {
        const order = this.currentOrder;
        if (!order) {
            return;
        }
        order.set_is_fiscalised(!order.is_fiscalised);
        this.notification.add(
            order.is_fiscalised
                ? _t("Fiscalise with Total VFD: ON")
                : _t("Fiscalise with Total VFD: OFF"),
            { type: "info" }
        );
        if (this.props.close) {
            this.props.close();
        }
    },
});
