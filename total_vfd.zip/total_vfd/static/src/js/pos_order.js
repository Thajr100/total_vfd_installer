/** @odoo-module **/

import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { patch } from "@web/core/utils/patch";
import { qrCodeSrc } from "@point_of_sale/utils";

patch(PosOrder.prototype, {
    setup(vals) {
        super.setup(vals);
        if (vals.is_fiscalised === undefined) {
            this.is_fiscalised = Boolean(this.config?.totalvfd_fiscalise_default);
        }
    },
    set_is_fiscalised(value) {
        this.is_fiscalised = Boolean(value);
    },
    export_for_printing(baseUrl, headerData) {
        const result = super.export_for_printing(baseUrl, headerData);
        if (this.fiscal_status === "success") {
            result.fiscal_status = this.fiscal_status;
            result.totalvfd_rctvnum = this.totalvfd_rctvnum;
            result.totalvfd_local_time =
                this.totalvfd_fiscal_time_display || this.totalvfd_local_time;
            result.totalvfd_verification_link = this.totalvfd_verification_link;
            if (this.totalvfd_verification_link) {
                result.totalvfd_qr_src = qrCodeSrc(this.totalvfd_verification_link, {
                    size: 120,
                });
            }
        }
        return result;
    },
});
