/** @odoo-module **/

import { PosStore } from "@point_of_sale/app/store/pos_store";
import { patch } from "@web/core/utils/patch";

patch(PosStore.prototype, {
    createNewOrder(data = {}) {
        const fiscalDefault = Boolean(this.config.totalvfd_fiscalise_default);
        return super.createNewOrder({
            ...data,
            is_fiscalised: data.is_fiscalised ?? fiscalDefault,
        });
    },
});
