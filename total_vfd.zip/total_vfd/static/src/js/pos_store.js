/** @odoo-module **/

import { PosStore } from "@point_of_sale/app/store/pos_store";
import { patch } from "@web/core/utils/patch";

const FISCAL_SYNC_FIELDS = [
    "fiscal_status",
    "totalvfd_rctvnum",
    "totalvfd_local_time",
    "totalvfd_verification_link",
    "totalvfd_fiscal_time_display",
];

patch(PosStore.prototype, {
    createNewOrder(data = {}) {
        const fiscalDefault = Boolean(this.config.totalvfd_fiscalise_default);
        return super.createNewOrder({
            ...data,
            is_fiscalised: data.is_fiscalised ?? fiscalDefault,
        });
    },
    async postSyncAllOrders(orders) {
        await super.postSyncAllOrders(...arguments);
        const current = this.get_order();
        if (!current) {
            return;
        }
        const synced = orders.find((o) => o.uuid === current.uuid);
        if (!synced) {
            return;
        }
        const patch = {};
        for (const field of FISCAL_SYNC_FIELDS) {
            if (synced[field] !== undefined) {
                patch[field] = synced[field];
            }
        }
        if (Object.keys(patch).length) {
            current.update(patch);
        }
    },
});
