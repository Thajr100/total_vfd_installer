# -*- coding: utf-8 -*-

import importlib
import logging
import subprocess
import sys

from odoo.addons.total_vfd.services.dependency_check import (
    missing_optional_qr_packages,
    missing_required_packages,
    pip_install_command,
    qr_install_command,
    qr_libraries_available,
)

_logger = logging.getLogger(__name__)

PIP_INSTALL_TIMEOUT = 300


def _pip_install(packages):
    if not packages:
        return
    base_cmd = [
        sys.executable,
        '-m',
        'pip',
        'install',
        '--disable-pip-version-check',
        '--no-warn-script-location',
    ]
    attempts = [
        base_cmd + packages,
        base_cmd + ['--user'] + packages,
    ]
    last_error = None
    for cmd in attempts:
        try:
            _logger.info('Total VFD: installing Python packages: %s', ' '.join(packages))
            subprocess.check_call(
                cmd,
                timeout=PIP_INSTALL_TIMEOUT,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            return
        except subprocess.CalledProcessError as exc:
            last_error = exc.stderr.decode('utf-8', errors='replace') if exc.stderr else str(exc)
            _logger.warning(
                'Total VFD: pip install attempt failed (%s): %s',
                ' '.join(cmd),
                last_error[:500],
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
            last_error = str(exc)
            _logger.warning('Total VFD: pip install failed: %s', exc)
    raise RuntimeError(last_error or 'pip install failed')


def _try_install_packages(packages):
    if not packages:
        return
    try:
        _pip_install(packages)
    except RuntimeError as exc:
        _logger.warning(
            'Total VFD: could not auto-install %s: %s',
            ', '.join(packages),
            exc,
        )
    importlib.invalidate_caches()


def _ensure_required_dependencies():
    missing = missing_required_packages()
    if not missing:
        return

    _logger.info(
        'Total VFD: missing required Python packages %s — attempting automatic install.',
        ', '.join(missing),
    )
    _try_install_packages(missing)
    still_missing = missing_required_packages()
    if still_missing:
        raise Exception(
            'Total VFD could not install required Python packages automatically.\n\n'
            f'Missing: {" ".join(still_missing)}\n\n'
            'Ask your server administrator to run on the Odoo server:\n'
            f'    {pip_install_command(still_missing)}\n\n'
            'Then restart Odoo and install this module again.'
        ) from None


def _ensure_optional_qr_dependencies():
    missing = missing_optional_qr_packages()
    if not missing:
        return

    _logger.info(
        'Total VFD: QR libraries missing (%s) — attempting automatic install.',
        ', '.join(missing),
    )
    _try_install_packages(missing)
    still_missing = missing_optional_qr_packages()
    if still_missing:
        _logger.warning(
            'Total VFD: QR code images disabled until these packages are installed: %s. '
            'Run: %s',
            ', '.join(still_missing),
            qr_install_command(),
        )


def pre_init_hook(env):
    """Never abort module load/upgrade if pip is unavailable in the container."""
    try:
        _ensure_required_dependencies()
    except Exception as exc:
        _logger.warning('Total VFD: required dependency check failed: %s', exc)
    try:
        _ensure_optional_qr_dependencies()
    except Exception as exc:
        _logger.warning('Total VFD: optional QR dependency check failed: %s', exc)


def post_init_hook(env):
    try:
        manager_group = env.ref('total_vfd.group_total_vfd_manager')
        admin_group = env.ref('base.group_system')
        manager_group.sudo().write({'users': [(4, user.id) for user in admin_group.users]})
    except Exception as exc:
        _logger.warning('Total VFD post-init (groups): %s', exc)

    env['ir.config_parameter'].sudo().set_param('total_vfd.setup_complete', '0')
    if qr_libraries_available():
        _logger.info(
            'Total VFD installed. Open Settings → Total VFD: configure the license validation '
            'server URL and API key first, then activate the module license.'
        )
    else:
        _logger.warning(
            'Total VFD installed without QR libraries. Fiscalisation works; QR images are '
            'disabled until your administrator runs: %s',
            qr_install_command(),
        )
